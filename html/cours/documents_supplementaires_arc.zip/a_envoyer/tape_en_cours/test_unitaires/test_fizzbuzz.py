import fizzbuzz


def test_fizzbuzz():
    assert fizzbuzz.regle_fizzbuzz(1) == "1"
    assert fizzbuzz.regle_fizzbuzz(5) == "fizz"
    assert fizzbuzz.regle_fizzbuzz(3) == "buzz"
    assert fizzbuzz.regle_fizzbuzz(15) == "fizzbuzz"


def test_division3():
    assert fizzbuzz.est_divisible_par_3(3)
    assert not fizzbuzz.est_divisible_par_3(4)
