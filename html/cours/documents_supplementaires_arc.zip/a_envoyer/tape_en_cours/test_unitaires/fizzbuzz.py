def est_divisible_par_3(nombre: int) -> bool:
    return nombre // 3 == nombre / 3


def est_divisible_par_5(nombre: int) -> bool:
    return nombre % 5 == 0


def regle_fizzbuzz(nombre: int) -> str:
    resultat = ""
    if est_divisible_par_5(nombre) and est_divisible_par_3(nombre):
        resultat = "fizzbuzz"
    elif est_divisible_par_5(nombre):
        resultat = "fizz"
    elif est_divisible_par_3(nombre):
        resultat = "buzz"
    else:
        resultat = str(nombre)
    return resultat


def fizzbuzz():
    for nombre in range(1, 101):
        print(regle_fizzbuzz(nombre))


if __name__ == "__main__":
    fizzbuzz()
