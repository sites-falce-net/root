Pour créer l'exe, il suffit de faire 

    pip install -r requirements
    pyinstaller appl_qt.spec 
    # aller voir dans dist/