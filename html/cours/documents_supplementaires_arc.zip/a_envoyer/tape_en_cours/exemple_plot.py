import numpy as np
import matplotlib.pyplot as plt

echiquier = np.zeros((8, 8))
plt.imshow(echiquier)
plt.savefig("toto.png")
plt.show()
