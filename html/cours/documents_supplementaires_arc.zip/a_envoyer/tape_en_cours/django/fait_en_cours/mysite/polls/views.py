from django.shortcuts import render
from .models import Question

# Create your views here.
from django.http import HttpResponse


def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")


def vue_matthieu(request):
    print(request, dir(request))
    all_questions = list(Question.objects.all())
    return HttpResponse(f"{all_questions[0].question_text}")
