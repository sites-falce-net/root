from django.urls import path
from search import views

from .filters import MatiereFilter, FournisseurFilter
from django_filters.views import FilterView

urlpatterns = [
    # URL d'accès à la page d'acceuil / page du tableau de bord
    path("", views.dashboard, name="dj-dashboard"),
    # URL pour accéder à la page recherche matière
    path(
        "searchMat",
        FilterView.as_view(
            filterset_class=MatiereFilter, template_name="search/matiere_list.html"
        ),
        name="dj-search_matiere",
    ),
    # URL pour accéder à la page recherche fournisseur
    path(
        "searchFournisseur",
        FilterView.as_view(
            filterset_class=FournisseurFilter,
            template_name="search/fournisseur_list.html",
        ),
        name="dj-search_fournisseur",
    ),
    # URL de la page de l'élémentarium
    path("elementarium/", views.elementarium, name="dj-elementarium"),
    # URL de la page Sign / d'enregistrement de compte
    path("register/", views.registerPage, name="dj-register"),
    # URL de la page Login de compte
    path("login/", views.loginPage, name="dj-login"),
    # URL de la page Logout de la session
    path("logout/", views.logoutUser, name="dj-logout"),
    # URL de la page utilisateur
    path("user/", views.userPage, name="user-page"),
    # URL pour aller dans la page matière "view"
    path("page_matiere/<str:pk>", views.pageMatiere, name="dj-page_matiere"),
    # Chemin pour la forme pour ajouter une nouvelle matière dans la base de donnée
    path("create_matiere/", views.createMatiere, name="dj-create_matiere"),
    # Chemin pour la forme de modification de matière
    path("update_matiere/<str:pk>/", views.updateMatiere, name="dj-update_matiere"),
    # Chemin pour la forme de suppression de matière
    path("delete_matiere/<str:pk>/", views.deleteMatiere, name="dj-delete_matiere"),
    # Chemin pour accéder à la page de téléchargement de la table matière sous forme CSV
    path("upload-csv/", views.matiere_upload, name="dj-upload_matiere"),
]
