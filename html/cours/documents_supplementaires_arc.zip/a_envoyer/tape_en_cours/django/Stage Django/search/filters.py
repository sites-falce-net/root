import django_filters
from .models import *
from django_filters import DateFilter

# Class pour filter les matières
class MatiereFilter(django_filters.FilterSet):
    
    class Meta:
        model = Matiere
        # On peut mettre tant d'attribut que l'on veut dans la liste fields
        fields = {
            'code_classe': ['icontains'],
            'code_matiere': ['icontains'], 
            'classe_matiere': ['icontains'], 
            'libelle_matiere': ['icontains'], 
            'AFNOR': ['icontains'],
            'nom_commercial': ['icontains']
        }
        # '__all__' pour mettre tous les attributs de la classe matière

# Class pour filter les fournisseurs
class FournisseurFilter(django_filters.FilterSet):

    class Meta:
        model = Fournisseur
        # On peut mettre tant d'attribut que l'on veut dans la liste fields
        fields = {
            'nom_fournisseur': ['icontains'],
            'code_fournisseur': ['icontains'],
            'numero_telephone': ['icontains'],
            'adresse': ['icontains']
        }