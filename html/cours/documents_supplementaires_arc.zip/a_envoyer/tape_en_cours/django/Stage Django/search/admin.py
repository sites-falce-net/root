from django.contrib import admin
from import_export.admin import ImportExportModelAdmin

# Register your models here.

from .models import *
from .models import Matiere

# admin.site.register(Matiere)
admin.site.register(Element)
admin.site.register(Fournisseur)
admin.site.register(Composition)
admin.site.register(Forme)
admin.site.register(Usage)
admin.site.register(Have_Usage)
admin.site.register(Have_Forme)

@admin.register(Matiere)
class ViewAdmin(ImportExportModelAdmin):
    pass