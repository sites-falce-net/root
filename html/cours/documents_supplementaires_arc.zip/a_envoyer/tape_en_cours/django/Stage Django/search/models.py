from django.db import models


# Create your models here.

# Définition de la table sous forme de classe
class Element(models.Model):
    # Définition des attributs
    
    nom_element = models.CharField(max_length=10, null=True)
    min = models.IntegerField(null=True)
    max = models.IntegerField(null=True)

    # L'affichage du nom de l'élément dans la base de données
    # la fonction __str__ associe une chaîne de caractèrs à l'objet Elèment-
    def __str__(self):
        return self.nom_element

# Définition de la table sous forme de classe
class Fournisseur(models.Model):
    # Définition des attributs
    nom_fournisseur = models.CharField(max_length=200, null=True)
    code_fournisseur = models.CharField(max_length=4, null=True, blank=True)
    numero_telephone = models.CharField(max_length=200, null=True, blank = True)
    adresse = models.CharField(max_length=200, null=True, blank = True)

    # L'affichage du nom du fournisseur dans la base de données
    # la fonction __str__ associe une chaîne de caractèrs à l'objet Fournisseur
    def __str__(self):
        return self.nom_fournisseur


# Définition de la table sous forme de classe
class Matiere(models.Model):
    # Définition des attributs
    code_matiere = models.CharField(max_length=200, null=True, blank=True)
    libelle_matiere = models.CharField(max_length=200, null=True, blank=True)
    code_classe = models.IntegerField(null=True, blank=True)
    classe_matiere = models.CharField(max_length=200, null=True, blank=True)
    code_sommeil = models.BooleanField(default=True)
    nom_interne = models.CharField(max_length=200, null=True, blank=True)
    AFNOR = models.CharField(max_length=200, null=True, blank=True)
    DIN = models.CharField(max_length=200, null=True, blank=True)
    AISI = models.CharField(max_length=200, null=True, blank=True)
    WNR = models.FloatField(null=True, blank=True)
    nom_commercial = models.CharField(max_length=200, null=True, blank=True)

    NB_piece_BEAM = models.IntegerField(null=True, blank=True)
    NB_piece_OHM = models.IntegerField(null=True, blank=True)
    
    prix_euros_kg = models.FloatField(null=True, blank=True)
    prix_dollars_kg = models.FloatField(null=True, blank=True)
    
    utilisation = models.CharField(max_length=500, null=True, blank=True)
    use = models.CharField(max_length=500, null=True, blank=True)
    
    densite = models.FloatField(null=True, blank=True)
    
    module_Young_min = models.IntegerField(null=True, blank=True)
    module_Young_max = models.IntegerField(null=True, blank=True)
    
    coeff_Poisson = models.FloatField(null=True, blank=True)

    HB_30_AV_TT_min = models.FloatField(null=True, blank=True)
    HB_30_AV_TT_max = models.FloatField(null=True, blank=True)
    HB_30_AP_TT_min = models.FloatField(null=True, blank=True)
    HB_30_AP_TT_max = models.FloatField(null=True, blank=True)

    HRC_30_AV_TT_min = models.FloatField(null=True, blank=True)
    HRC_30_AV_TT_max = models.FloatField(null=True, blank=True)
    HRC_30_AP_TT_min = models.FloatField(null=True, blank=True)
    HRC_30_AP_TT_max = models.FloatField(null=True, blank=True)

    allongement_min = models.FloatField(null=True, blank=True)
    allongement_max = models.FloatField(null=True, blank=True)

    limite_min = models.FloatField(null=True, blank=True)
    limite_max = models.FloatField(null=True, blank=True)

    resistance_min = models.FloatField(null=True, blank=True)
    resistance_max = models.FloatField(null=True, blank=True)

    # resilience_min = models.FloatField(null=True, blank=True)
    # resilience_max = models.FloatField(null=True, blank=True)

    chaleur = models.FloatField(null=True, blank=True)

    conductivite_20_deg = models.FloatField(null=True, blank=True)
    conductivite_500_deg = models.FloatField(null=True, blank=True)

    coeff_dilatation_100_deg = models.FloatField(null=True, blank=True)
    coeff_dilatation_300_deg = models.FloatField(null=True, blank=True)
    coeff_dilatation_500_deg = models.FloatField(null=True, blank=True)

    temperature_spe_AC1 = models.FloatField(null=True, blank=True)
    temperature_spe_AC3 = models.FloatField(null=True, blank=True)
    temperature_spe_MS = models.FloatField(null=True, blank=True)
    temperature_spe_MF = models.FloatField(null=True, blank=True)
    temperature_spe_TF = models.FloatField(null=True, blank=True)

    C_min = models.FloatField(null=True, blank=True)
    C_max = models.FloatField(null=True, blank=True)

    Si_min = models.FloatField(null=True, blank=True)
    Si_max = models.FloatField(null=True, blank=True)

    Mn_min = models.FloatField(null=True, blank=True)
    Mn_max = models.FloatField(null=True, blank=True)

    S_min = models.FloatField(null=True, blank=True)
    S_max = models.FloatField(null=True, blank=True)

    P_min = models.FloatField(null=True, blank=True)
    P_max = models.FloatField(null=True, blank=True)

    Cr_min = models.FloatField(null=True, blank=True)
    Cr_max = models.FloatField(null=True, blank=True)

    Ni_min = models.FloatField(null=True, blank=True)
    Ni_max = models.FloatField(null=True, blank=True)

    Mo_min = models.FloatField(null=True, blank=True)
    Mo_max = models.FloatField(null=True, blank=True)

    Sn_min = models.FloatField(null=True, blank=True)
    Sn_max = models.FloatField(null=True, blank=True)

    Pb_min = models.FloatField(null=True, blank=True)
    Pb_max = models.FloatField(null=True, blank=True)

    Zn_min = models.FloatField(null=True, blank=True)
    Zn_max = models.FloatField(null=True, blank=True)

    Cu_min = models.FloatField(null=True, blank=True)
    Cu_max = models.FloatField(null=True, blank=True)

    W_min = models.FloatField(null=True, blank=True)
    W_max = models.FloatField(null=True, blank=True)

    Fe_min = models.FloatField(null=True, blank=True)
    Fe_max = models.FloatField(null=True, blank=True)

    Co_min = models.FloatField(null=True, blank=True)
    Co_max = models.FloatField(null=True, blank=True)

    Ti_min = models.FloatField(null=True, blank=True)
    Ti_max = models.FloatField(null=True, blank=True)

    Al_min = models.FloatField(null=True, blank=True)
    Al_max = models.FloatField(null=True, blank=True)



    # Les clés étrangères
    fournisseur = models.ForeignKey(Fournisseur, null=True, on_delete=models.SET_NULL)


    # L'affichage du libellé matière dans la base de données
    # la fonction __str__ associe une chaîne de caractèrs à l'objet Matière
    def __str__(self):
        return self.libelle_matiere


class Forme(models.Model):
    nom_forme = models.CharField(max_length=20, null=True)

    def __str__(self):
        return self.nom_formeManyToManyField

class Usage(models.Model):
    nom_type_piece = models.CharField(max_length=20, null=True)


class Have_Usage(models.Model):
    usage_matiere = models.ManyToManyField(Matiere)
    usage_Types_pieces = models.ManyToManyField(Usage)

class Have_Forme(models.Model):
    have_forme_matiere = models.ManyToManyField(Matiere)
    have_forme_forme = models.ManyToManyField(Forme)

class Composition(models.Model):
    pourcent_element = models.FloatField(null=True)
    composition_matiere = models.ManyToManyField(Matiere)
    composition_fournisseur = models.ManyToManyField(Fournisseur)

