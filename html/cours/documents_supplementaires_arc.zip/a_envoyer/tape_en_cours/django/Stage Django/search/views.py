import csv, io
from django.contrib.auth.decorators import permission_required

from django.contrib.auth.models import Group


from django.shortcuts import render, redirect
from django.http import HttpResponse
# On importe les modèles () pour pouvoir les utiliser dans les views
from search.models import *
from search.forms import MatiereForm, CreateUserForm
# On importe le module filter pour la fonctionnalité de recherche dans la Bdd
from .filters import MatiereFilter
from django.contrib.auth.forms import UserCreationForm

# Ce module assure l'authentification
from django.contrib.auth import authenticate, login, logout

# Importation des "flash messages"
from django.contrib import messages

# Importation des "decorators"
from django.contrib.auth.decorators import login_required
from .decorators import unauthenticated_user, allowed_users, expert_only


# Importation des modules pour les fichiers pdf
from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa


##### Les views Django #####


# View de la fonctionnalité recherche matière
def searchMatiere(request):
    # On rassemble toutes les matières dans la liste matiere_list
    matiere_list = Matiere.objects.all()
    # On fait appel à la classe MatiereFilter depuis le fichier filters.py pour filtrer les matières
    matiere_filter = MatiereFilter(request.GET, queryset=matiere_list)
    # On retourne la requête de  recherche dans la page HTML matiere_list.html
    return render(request, 'search/matiere_list.html', {'filter': matiere_filter})

# View de la fonctionnalité recherche fournisseur
def searchFournisseur(request):
    # On rassemble toutes les matières dans la liste matiere_list
    fournisseur_list = Matiere.objects.all()
    # On fait appel à la classe MatiereFilter pour filtrer les matières
    fournisseur_filter = MatiereFilter(request.GET, queryset=fournisseur_list)
    return render(request, 'search/fournisseur_list.html', {'filter': fournisseur_filter})

# View de la fonctionnalité de la page d'enregistrement de compte
def registerPage(request):
    # Si l'utilisateur est authentifié 
    if request.user.is_authenticated:
        # On se redirige vers la page d'acceuil (le dashboard)
        return redirect('dj-dashboard')
    else:
        # On crée un formulaire d'utilisateur à l'aide de la méthode CreateUserForm importé depuis le fichier forms.py
        form = CreateUserForm()

        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                # Dans le cas ou le formulaire est valide, on enregistre dans la base de données les informations du formulaire
                user = form.save()

                # Cette ligne de code sert à effacer les champs username / password après la validation du formulaire
                username = form.cleaned_data.get('username')

                # Query the group
                group = Group.objects.get(name='Utilisateur')
                user.groups.add(group)

                # Dans le cas ou l'enregistrement du compte est validé on affiche le message suivant 
                messages.success(request, 'Account was created for ' + username)

                # Et après l'enregistrement on se redirige automatiquement vers la page de Login
                return redirect('dj-login')

        # la variable context nous aide à y placer le contenu qui aura dans les pages HTML
        context = {'form': form}
        return render(request, 'search/register.html', context)

# View de la page de Login

# Cette ligne de code nous interdit d'accéder à la page de login quand on est authentifié
@unauthenticated_user 
def loginPage(request):
    # Si la méthode de la requête est la méthode post
    if request.method == 'POST':
        # On récupère ce qui est écrit dans le champ username et on le met dans la variable username
        username = request.POST.get('username')
        # On récupère ce qui est écrit dans le champ password et on le met dans la variable password
        password = request.POST.get('password')

        # On attribut à la variable user la requête ainsi que les deux variables username et password
        user = authenticate(request, username=username, password=password)

        # Si l'utilisateur (user) n'est pas vide 
        if user is not None:
            # on l'attribut à la fonction login
            login(request, user)
            # Et on se redirige vers la page d'acceuil Dashboard
            return redirect('dj-dashboard')
        else:
            # Sinon, si l'utilisateur user est vide on affiche le message ci-dessous
            messages.info(request, 'Username OR password is incorrect')
    context = {}
    # Et on reste dans la page de login
    return render(request, 'search/login.html', context)

# View de la page utilisateur / la page d'acceuil en mode utilisateur normal
def userPage(request):
	context = {}
	return render(request, 'search/user.html', context)

# View de la page 
def logoutUser(request):
    logout(request)
    # On se regirige vers la page login après la ferméture de la session
    return redirect('dj-login')

# Cette ligne de code fait partie des decorators programmés dans le fichier "decorators.py" 
# Elle sert à obliger l'application de ne pas se placer dans la session jusque ce que l'authentification soit faite
@login_required(login_url='dj-login')
@expert_only
def dashboard(request):
    matieres = Matiere.objects.all()
    return render(request, 'search/dashboard.html', {'matieres': matieres})


# Cette ligne de code fait partie des decorators programmés dans le fichier "decorators.py" 
# Elle sert à obliger l'application de ne pas se placer dans la session jusque ce que l'authentification soit faite
@login_required(login_url='dj-login')
def elementarium(request):
    return render(request, 'search/elementarium.html')

# Cette ligne de code fait partie des decorators programmés dans le fichier "decorators.py" 
# Elle sert à obliger l'application de ne pas se placer dans la session jusque ce que l'authentification soit faite
@login_required(login_url='dj-login')
def profile(request):
    return render(request, 'search/profile.html')

# Cette ligne de code fait partie des decorators programmés dans le fichier "decorators.py" 
# Elle sert à obliger l'application de ne pas se placer dans la session jusque ce que l'authentification soit faite
@login_required(login_url='dj-login')
def createMatiere(request):
    # On crée un formulaire de la matière
    form = MatiereForm()
    # Si la méthode de la requête est la méthode POST
    if request.method == 'POST':
        # On attribut le formulaire à la variable form
        form = MatiereForm(request.POST)
        # Si la form est validé 
        if form.is_valid():
            # On l'enregistre dans la base de données
            form.save()
            # Après d'enregistrement on se redirige vers la page d'accueil (le tableau de bord)
            return redirect('/')

    # On place le formulaire dans le dictionnaire context
    context = {'form': form}
    # On fait appel à la page HTML matiere_form contenant le formulaire matière
    return render(request, 'search/matiere_form.html', context)


# Cette ligne de code fait partie des decorators programmés dans le fichier "decorators.py" 
# Elle sert à obliger l'application de ne pas se placer dans la session jusque ce que l'authentification soit faite
@login_required(login_url='dj-login')
def updateMatiere(request, pk):
    # Cette ligne de code nous permet d'avoir les champs pré-rempli lorsqu'on veut les modifier
    matiere = Matiere.objects.get(id=pk)
    form = MatiereForm(instance=matiere)

    if request.method == 'POST':
        # print('Printing POST: ', request.POST)
        form = MatiereForm(request.POST, instance=matiere)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'form': form}
    return render(request, 'search/matiere_form.html', context)

# Cette ligne de code fait partie des decorators programmés dans le fichier "decorators.py" 
# Elle sert à obliger l'application de ne pas se placer dans la session jusque ce que l'authentification soit faite
@login_required(login_url='dj-login')
def deleteMatiere(request, pk):
    # On regroupe toutes les matières dans la liste matiere
    matiere = Matiere.objects.get(id=pk)
    if request.method == 'POST':
        # cette fonction supprime la matière
        matiere.delete()
        # Après la suppression on se redirige vers la page d'accueil
        return redirect('/')

    context = {'matiere': matiere}
    # On retourne la page delete.html
    return render(request, 'search/delete.html', context)

# Le view de la page matière contenant la fiche technique de chaque matière
def pageMatiere(request, pk):
    # le pk représente la clé primaire distinguant chaque matière
    # matieres représente la liste contenant toutes les matières de la base de données
    matieres = Matiere.objects.filter(id=pk)
    context = {'matieres': matieres}
    # On retourne la page HTML page_matiere de la fiche matière
    return render(request, 'search/page_matiere.html', context)


## CSV part

@permission_required('admin.can_add_log_entry')
def matiere_upload(request):
    template = 'search/matiere_upload.html'
    prompt = {
        'order': 'Order of the CSV code matière ou nta ghadi'
    }

    if request.method == "GET":
        return render(request, template, prompt)

    csv_file = request.FILES['file']

    if not csv_file.name.endswith('.csv'):
        messages.error(request, 'This ain\'t a csv file')

    data_set = csv_file.read().decode('UTF-8')
    io_string = io.StringIO(data_set)
    next(io_string)
    for column in csv.reader(io_string, delimiter=',', quotechar=" "):
        _, created = Matiere.objects.update_or_create(
            code_matiere = column[0],
            libelle_matiere = column[1],
            classe_matiere = column[2],
            nom_interne = column[3],
            AFNOR = column[4]
        )
    context = {}
    return render(request, template, context)

# Cette ligne de code fait partie des decorators programmés dans le fichier "decorators.py" 
# Elle sert à obliger l'application de ne pas se placer dans la session jusque ce que l'authentification soit faite
@login_required(login_url='dj-login')
def about(request):
    matieres = Matiere.objects.all()
    myFilter = MatiereFilter(request.GET, queryset=matieres)
    matieres = myFilter.qs

    context = {'myFilter': myFilter, 'matieres': matieres}
    return render(request, 'search/about.html', context)