# Importation des modules nécessaires
from django.forms import ModelForm
from search.models import Matiere
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms


# La classe MatiereForm pour le formulaire de créer matière
class MatiereForm(ModelForm):
    class Meta:
        # Le nom du modèle qu'on va utiliser 
        model = Matiere 
        # Les champs du modèle dont on a besoin
        fields =  ['code_matiere', 'classe_matiere', 'libelle_matiere', 'AFNOR', 'DIN', 'AISI', 'nom_commercial', 'fournisseur'] 
        # NB: avec le '__all__' on peut mettre tous les champs de la table matière, dans le liste fields on peut ajouter tant qu'on veut de champ de la table matière

# La classe MatiereForm pour le formulaire d'enregistrement
class CreateUserForm(UserCreationForm):
    class Meta:
        # Le modèle User qu'on utilise cette fois-ci
        model = User
        # Les champs du modèle à utiliser
        fields = ['username', 'email', 'password1', 'password2']
        