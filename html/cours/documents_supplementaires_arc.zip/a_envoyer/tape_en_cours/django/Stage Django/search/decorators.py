from django.http import HttpResponse
from django.shortcuts import redirect

# Cette fonction nous permet de diriger l'authentification vers la page d'accueil le dashboard
def unauthenticated_user(view_func):
    def wrapper_func(request, *args, **kwargs):
        # Si l'utilisateur est authentifié 
        if request.user.is_authenticated:
            # on se redirige vers le dashboard
            return redirect('dj-dashboard')
        else:
            return view_func(request, *args, **kwargs)

    return wrapper_func


# Cette fonction gère la redirection vers les pages interdites par les utilisateurs simples
def allowed_users(allowed_roles=[]):
    def decorator(view_func):
        def wrapper_func(request, *args, **kwargs):
            group = None
            if request.user.groups.exists():
                group = request.user.groups.all()[0].name
            if group in allowed_roles:
                return view_func(request, *args, **kwargs)
            else:
                return HttpResponse('Vous n\'avez pas le droit d\'accéder à cette page')
        return wrapper_func
    return decorator

# La gestion de la permission des pages permis pour les experts seuelement
def expert_only(view_func):
    def wrapper_func(request, *args, **kwargs):
        group = None
        if request.user.groups.exists():
            group = request.user.groups.all()[0].name
        # si on est en mode utilisateur normal on se redirige vers la page d'accueil user-page
        if group == 'Utilisateur':
            return redirect('user-page')
        
        # Si on est en mode expert on se redirige vers le dashboard avec toutes les fonctionnalités CRUD
        if group == 'Expert':
            return view_func(request, *args, **kwargs)

    return wrapper_func