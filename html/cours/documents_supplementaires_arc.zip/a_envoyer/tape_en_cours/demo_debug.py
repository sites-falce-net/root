import random

p = "Avoir plus d'une corde à son arc"
nouvelle_chaine = ""


def toto(x):
    print("dans toto")
    return x


for lettre in p:
    if random.random() > 0.5:
        1 / 0

print("fini")
