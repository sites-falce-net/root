default_app_config = 'emaildigest.apps.EmaildigestConfig'
