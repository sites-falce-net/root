from hnclone.settings.base import *

debug = True
