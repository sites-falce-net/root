import emb

print(emb.numargs())
print("toto")
