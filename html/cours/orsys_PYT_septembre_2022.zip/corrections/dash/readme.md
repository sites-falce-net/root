* rajouter des urls gérées par flask : https://towardsdatascience.com/how-to-build-a-complex-reporting-dashboard-using-dash-and-plotl-4f4257c18a7f

* gallerie d'exemples : https://dash-gallery.plotly.host/Portal/
    * mise à jour en temps réel : 
        * trader : 
            * https://dash-gallery.plotly.host/dash-web-trader/ 
            * https://github.com/plotly/dash-sample-apps/blob/master/apps/dash-web-trader/app.py
        * wind : 
            * https://dash-gallery.plotly.host/dash-wind-streaming/
            * https://github.com/plotly/dash-sample-apps/tree/master/apps/dash-wind-streaming

    * spatial : 
        * https://dash-gallery.plotly.host/dash-spatial-clustering/
        * https://github.com/plotly/dash-sample-apps/tree/dash-spatial-clustering/apps/dash-spatial-clustering