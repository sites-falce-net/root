def format(x, y):
    return str(x).zfill(y)