# Compile CTypes extension 


## compilation

make test2.so
make test1.so

# Use 

```
python main.py
# Hello MatthieuMatthieuMatthieuMatthie
# Hello MatthieuMatthieuMatthieuMatthie
# factorielle 0 : 1
# factorielle 1 : 1
# factorielle 2 : 2
# factorielle 3 : 6
# factorielle 4 : 24
# factorielle 5 : 120
# factorielle 6 : 720
# factorielle 7 : 5040
# factorielle 8 : 40320
# factorielle 9 : 362880
```