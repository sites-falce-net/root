# Introduction to python

## Duration 

1h

## Program for the week

* present the concept of computer language
* present the history / usecase / context of python
* install python + IDE => Thonny 
* write / execute first program
* present the syllabus of the course 

## Quizz

NA

## Exercice for next week 

Extract / formalize the algorithm of a simple game (guess a number). 
Specify that it should be the role of the person saying it's more, it's less. 

## Feedback 

NA