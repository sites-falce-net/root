# Python and webapis to manipulate data

## Duration 

2h

## Program for the week

* strings manipulation
* lists / dicts manipulation 
* create some docx document using data in a JSON

## Quizz

2 questions : 

1. read some code and find what it does
2. write some code to get the same output as given

## Live Coding

* correction of the assignment 
* create a docx document using data in a nested datastructure

## Exercice for next week 

Midterm project : 

* use an API to get the location of a city
* use an API to get weather forecast data 
* format the output to create some office documents (csv, docx, pptx, ...)

## Feedback 

The project was too long to do correctly. It took me 2-3h to complete, so I don't know how long the students took to finish it. 

It could be improved using this :
* explain how to simulate a webapi request (for faster developments)
* explain more precisly how to generate a docx document
* explain more the expected outcomes