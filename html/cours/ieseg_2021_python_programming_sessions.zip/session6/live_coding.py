from docx import Document

document = Document()


movie = {
    "title": "The cucco's calling",
    "Author": "Matthieu",
    "detail": {
        "isbn": "tot",
        "language": "en"
    },
    "price": [
        {
            "type": "dvd",
            "value": 12
        },
        {
            "type":  "on demand",
            "value": 4
        },
    ]
}

print(movie)
document.add_heading("The name of the movie is " + movie["title"])

for i in range(2):
    price = movie["price"][i]
    print(price)
    document.add_paragraph("The price of the " + price["type"] + " version is: " + str(price["value"]))

document.save("movie.docx")
print("The movie is in", movie["detail"]["language"])


