# bored API (find an activity)

import requests
import collections 


# activities = []
# keys = []
# iteration_number = 0
# 
# while len(activities) < 10 and iteration_number < 20:
#     response = requests.get("https://boredapi.com/api/activity", params={'participants': 2})
#     iteration_number += 1
#     json_response = response.json()
#     print(json_response)
#     print(keys, iteration_number)
#     if json_response["key"] in keys:
#         pass
#     else:
#         activities.append(json_response["activity"])
#         keys.append(json_response["key"])
#     
# print(activities)
# print(collections.Counter(activities))


response = requests.get("http://recipepuppy.com/api", params={'i': "onions"})
results = response.json()["results"]
print(response.json())
#print(type(results), results)
# first = results[0]
# print(type(first), first)

for result in results:
    print(result["title"].strip())
    for ingredient in result["ingredients"].split(", "):
        print("   *", ingredient.strip())
    print()