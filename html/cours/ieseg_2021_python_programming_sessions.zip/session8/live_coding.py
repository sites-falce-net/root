import json
import requests
from docx import Document
from docxtpl import DocxTemplate


# MAPQUEST_API_KEY="hAGwKKrBmQIiqpaKQfZ0EgaGPyVy3EYD"
# payload={"key": MAPQUEST_API_KEY, "location": "Place du Casino, Monaco, Monte Carlo"}
# r = requests.get("http://open.mapquestapi.com/geocoding/v1/address", payload)
# r.json() # json.loads(r.text)


f = open("report.docx", "w")
f.write("toto")
f.close()

document = Document()
document.add_heading('Weather forecast', 0)
document.save('real_report.docx')


#2 courses :
#    * Promagrammation Python
#        * public : Développeurs, Expert Métier
#        * duration : 5j
#    
#    * Programmation HTML
#        * public : Intégrateurs, Entrepreneurs
#        * duration : 2j
    
courses = [
    {
        "title": "Programmation Python",
        "public": ["Développeurs", "Expert Métier"],
        "duration": "5j",
        "output_name": "python.docx"
    },
    {
        "title": "Programmation HTML",
        "public": ["Intégrateurs", "Entrepreneurs"],
        "duration": "2j",
        "output_name": "html.docx"
    },
]

for course in courses:
    document = DocxTemplate("template.docx")
    
    template_values = {}
    template_values["targets"] = course["public"]
    template_values["duration"] = course["duration"]
    template_values["title"] = course["title"]

    document.render(template_values)
    document.save(course["output_name"])
    


from flask import Flask, render_template

app = Flask(__name__)

@app.route('/hello/')
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello.html', name=name)

@app.route('/courses/')
@app.route('/courses/<name>')
def course(name=None):
    my_course = {}
    for course in courses:
        if name == course["title"]:
            my_course = course
    
    return render_template('course.html', course=my_course)
