from statistics import mean, variance
from urllib import parse
import csv

import requests
from bs4 import BeautifulSoup

RATING_CONVERTION = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}

def get_next_url(soup):
    try:
        return soup.find("li", class_="next").a.get("href")
    except Exception as e:
        print("[logger]", e)
        return None

def extract_infos_from_book(article):
    book = {
        "rating": RATING_CONVERTION[article.find("p", class_="star-rating")["class"][1]],
        "title": article.h3.a.get("title"),
        "cover_url":article.find("div", class_="image_container").a.img.get("src"),
        "description_url": article.find("div", class_="image_container").a.get("href"),
        "price": float(article.find("p", class_="price_color").text[1:]),
        "stock_status": article.find("div", class_="product_price").find("p", class_="instock").text.strip() == "In stock"
    }
    return book


def extract_book_infos_from_url(url):
    page = requests.get(url)
    print(f"[logger] requesting {page.url}")
    soup = BeautifulSoup(page.content, 'html.parser')
    articles = soup.findAll('article')
    extracted = [extract_infos_from_book(article) for article in articles]
    return soup, extracted


def question1():
    """We want to answer: how many books are not in stock in the first 3 pages.

    We modified the question to query all the pages
    Answer: All the books are in stock
    """
    current_url = "http://books.toscrape.com/index.html"
    books = []
    
    soup, scrapped_books = extract_book_infos_from_url(current_url)
    books.extend(scrapped_books)
    next_url = get_next_url(soup)
    while True:
        current_url = parse.urljoin(current_url, next_url)
        soup, scrapped_books = extract_book_infos_from_url(current_url)
        books.extend(scrapped_books)
        next_url = get_next_url(soup)
        if not next_url:
            break
    
    nb_not_in_stocks = len([b for b in books if not b["stock_status"]])
    print(f"There are {nb_not_in_stocks} books not in stock in the catalogue")
    return nb_not_in_stocks
    
def question2():
    """Compute the average price for the category philosophy.
    The category fits on 1 page.
    """
    current_url = "http://books.toscrape.com/catalogue/category/books/philosophy_7/index.html"
    soup, scrapped_books = extract_book_infos_from_url(current_url)
    average_price_for_books = mean([b["price"] for b in scrapped_books])
    print(f"The avarage price for the books in the page {current_url} is {average_price_for_books}")
    return average_price_for_books

def question3():
    """Given a CSV with titles and prices for a concurrent seller, find where the books are cheaper.

    We need to change a little bit the data for this one, and but the informations in a dictionnary {title: price}.
    """
    
    # we load the concurrents
    concurrent_prices = {}
    with open("./prices.csv") as concurrent_prices_file:
        reader = csv.DictReader(concurrent_prices_file)
        for row in reader:
            concurrent_prices[row["title"]] = float(row["amazon_price"])
    
    # we load our infos (in real life, we should have access to the price database)
    to_scrape_url = "http://books.toscrape.com/index.html"
    soup, our_prices = extract_book_infos_from_url(to_scrape_url)
    our_prices = {b["title"]: b["price"] for b in our_prices}
    
    # maybe some books will be avalaible on some plateforms and not on another
    ## we use sets (for an easier manipulation) to see which books are available where
    our_titles = set(our_prices.keys())
    concurrent_titles = set(concurrent_prices.keys())
    books_only_on_concurrent = concurrent_titles - our_titles
    books_only_on_our_plateform = our_titles - concurrent_titles
    
    print(f"books only avalaible on the concurrent: {books_only_on_concurrent}")
    print(f"books only avalaible on our platform: {books_only_on_our_plateform}")
    
    # we check where the books are cheaper
    cheaper_on_our_plateforms = []
    cheaper_on_concurrents = []
    same_prices = []
    for title in (concurrent_titles | our_titles):
        # maybe some books will not be in one platform catalogue
        # in this case, we say that it's price is infinite
        # (will be better to buy on the other platform)
        infinite = 1e10
        concurrent_price = concurrent_prices.get(title, infinite)
        our_price = our_prices.get(title, infinite)
        if concurrent_price == our_price:
            same_prices.append(title)
        elif concurrent_price > our_price:
            cheaper_on_our_plateforms.append(title)
        else:
           cheaper_on_concurrents.append(title)
    
    print(f"Books cheaper on our catalogue: {', '.join(cheaper_on_our_plateforms)}")
    print(f"Books cheaper on the concurrent: {', '.join(cheaper_on_concurrents)}")
    return same_prices, cheaper_on_concurrents, cheaper_on_our_plateforms

def main():
    question1()
    print("")
    question2()
    print("")
    question3()