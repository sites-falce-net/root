# Conclusion of the python programming course

## Duration 

2h

## Program for the week

* explain what is possible to do with the python they know
* show them how to use template documents (pptx, docx) 
    * concept of Jinja and templating 
* show them how to create a website using flask 
    * same Jinja and templating concept
* discussion about the individual projects and tips 

## Quizz

Explain some code and see how we can modify it (concept: understand the data pipeline)

## Live coding 

* explain the correction of last week code + mid term assignment 
* show templating with docx-templating (speaks more to the students, because it's possible to make a nice document automatically)

## Exercice for next week 

NA (last session)

## Feedback 

The students still struggle to understand why genereting a docx is not done with `open(..., 'w')` => missing explanation of the text and binary file types (see in `explain file types`, one is created correctly, one is created using open)

Students feedback 
* too difficult, especially when we started to use the webapis, office outputs
* not enough clarity in the assignments (my fault clearly)
* some of them liked the course