# Intro to functions

## Duration 

2h

## Program for the week

* correction of the week 2 assignment 
* quizz 
* consolidation of week 2 
* introduction to functions 

## Quizz

Subject is in quizz_subject_and_correction.py

2 questions : 

1. explain and correct some python code (syntax / grammar)
    * difference assignation <=> equality
    * syntax error (indent, missing semicolumns, missing quotes around strings)
1. fix an incorect result 
    * talk about the concept of blocks 
    * see the impact of indenting a line 

## Live coding 

* refactor some code to extract the functions 
* create some functions 
* work on parameters and return values 

## Exercice for next week 

Draw some nice geometric shapes using turtle 

Concepts:
* iteration 
* problem solving (identify and reproduce a pattern)
* master basic python litteracy 
* ideally the students have to use functions to separate the different exercices

## Feedback 

The students don't understand the concept of functions and returned values. This is because we use "impure" functions with turtle (the don't have to return anything). 