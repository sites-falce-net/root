import turtle

bob = turtle.Turtle()
bob.speed(0)

# walls
bob.forward(100)
bob.left(90)
bob.forward(100)
bob.left(90)
bob.forward(100)
bob.left(90)
bob.forward(100)
bob.left(90)

# return to roof
bob.penup()
bob.forward(100)
bob.left(90)
bob.forward(100)
bob.pendown()

# draw roof
bob.left(45)
bob.forward(100/1.414)
bob.left(90)
bob.forward(100/1.414)

# go to door
bob.penup()
bob.left(45)
bob.forward(100)
bob.left(90)
bob.forward(45)
bob.pendown()

# draw door
bob.left(90)
bob.forward(20)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(20)

# go to window right
bob.penup()
bob.left(90)
bob.forward(45)
bob.left(90)
bob.forward(70)
bob.left(90)
bob.forward(20)
bob.pendown()

# draw right window
bob.forward(10)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(10)

# go to left window
bob.penup()
bob.right(90)
bob.forward(50)
bob.pendown()

# draw left window
bob.forward(10)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(10)

bob.hideturtle()