import turtle
import random

bob = turtle.Turtle()
bob.speed(0)

# walls
random_number = random.random()
if random_number < 0.25:
    bob.color("blue")
elif random_number < 0.50:
    bob.color("red")
elif random_number < 0.75:
    bob.color("green")
else:
    bob.color("black")

bob.forward(100)
bob.left(90)
bob.forward(100)
bob.left(90)
bob.forward(100)
bob.left(90)
bob.forward(100)
bob.left(90)

# return to roof
bob.penup()
bob.forward(100)
bob.left(90)
bob.forward(100)
bob.pendown()

# draw roof
random_number = random.random()
if random_number < 0.25:
    bob.color("blue")
elif random_number < 0.50:
    bob.color("red")
elif random_number < 0.75:
    bob.color("green")
else:
    bob.color("black")

bob.left(45)
bob.forward(100/1.414)
bob.left(90)
bob.forward(100/1.414)

# go to door
random_number = random.random()
if random_number < 0.25:
    bob.color("blue")
elif random_number < 0.50:
    bob.color("red")
elif random_number < 0.75:
    bob.color("green")
else:
    bob.color("black")
bob.penup()
bob.left(45)
bob.forward(100)
bob.left(90)
bob.forward(45)
bob.pendown()

# draw door
bob.left(90)
bob.forward(20)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(20)

# go to window right
bob.penup()
bob.left(90)
bob.forward(45)
bob.left(90)
bob.forward(70)
bob.left(90)
bob.forward(20)
bob.pendown()

# draw right window
random_number = random.random()
if random_number < 0.25:
    bob.color("blue")
elif random_number < 0.50:
    bob.color("red")
elif random_number < 0.75:
    bob.color("green")
else:
    bob.color("black")

bob.forward(10)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(10)

# go to left window
bob.penup()
bob.right(90)
bob.forward(50)
bob.pendown()

# draw left window
random_number = random.random()
if random_number < 0.25:
    bob.color("blue")
elif random_number < 0.50:
    bob.color("red")
elif random_number < 0.75:
    bob.color("green")
else:
    bob.color("black")

bob.forward(10)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(10)
bob.right(90)
bob.forward(10)

bob.hideturtle()