# question
## list the errors different errors, explain them and 
## fix this code
name == "Matthieu"
password = "hunter1"

if name == Matthieu and password == "hunter1"
    print(correct password)
else:
print("incorrect password")
    
# SyntaxError: invalid syntax at line 4 (assignation instead of comparision)
# SyntaxError: invalid syntax at line 4 (missing semicolumn)
# SyntaxError: invalid syntax at line 5 (variables instead of string, put into quote)
# IndentationError: expected an indented block at line 7 (indent the line)
# NameError: name 'name' is not defined at line 1 (comparision instead of assignation, remove one =, the variable name doesn't exist at that time of the programm)

######################################

# question 2
## you can't change your age, you don't want to enter the club if you can't enter
## fix this code
age = 17
if age < 18:
    print("you can't enter the club")
else:
    print("you can enter the club")
print("entering the club")

## indent the "entering the club" to make it part of the "else" block