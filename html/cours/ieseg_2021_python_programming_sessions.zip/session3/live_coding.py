import turtle
bob = turtle.Turtle()


# a function to draw a polygon using turtle
# TODO : allow user to pass the size of the side
def polygon(the_number_of_sides, the_turtle):
    for index in range(the_number_of_sides):
        print(index)
        the_turtle.forward(50)
        the_turtle.left(360/nb_sides)    


# draw some triangles and turn a little bit to make a masterpiece 
nb_sides = 3
for tirangle_number in range(50):
    polygon(nb_sides, bob)
    bob.left(10)


########################################
    
# a function that adds 2 numbers
def addition(a, b):
    return a + b

r = addition(1, 2)
print(addition(r, 3))