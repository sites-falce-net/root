import turtle
from pprint import pprint
from time import sleep

bob = turtle.Turtle()

def move(trtl, x, y):
    trtl.penup()
    trtl.goto(x, y)
    trtl.pendown()


def prepare(trtl, scale, length):
    dots = {}
    trtl.penup()
    for i in range(scale):
        trtl.forward(length)
        trtl.left(360/scale)
        # trtl.dot()
        dots[i] = trtl.position()

    return dots


def draw(trtl, dots, factor):
    for i, p in dots.items():
        move(trtl, *p)
        j = factor*i % len(dots)
        trtl.goto(*dots[j])


# xs = [-200, -100, 0, 100, 200]
# for i in range(100):
#     move(bob, xs[i%5], 200 - i//5 * 100)
#     draw(bob, factor=i, scale=50, length=5)


numbers = [2, 3, 4, 21, 29, 33, 34, 49, 51, 66, 67, 68, 73, 76, 79, 80, 86, 91, 99]


bob.speed(0)
bob.color('purple')
move(bob, 0, -120)
# dots = prepare(bob, scale=100, length=10)
# draw(bob, dots, factor=2)

dots = prepare(bob, scale=200, length=4)

# for n in numbers:
#     print(n)
#     bob.speed(0)
#     draw(bob, dots, factor=n)
#     sleep(1)
#     bob.clear()

draw(bob, dots, factor=86)
# draw(bob, dots, factor=29)
# draw(bob, dots, factor=33)
# draw(bob, dots, factor=34)
# draw(bob, dots, factor=49)
# draw(bob, dots, factor=51)
# draw(bob, dots, factor=66)
# draw(bob, dots, factor=67)
# draw(bob, dots, factor=68)
# draw(bob, dots, factor=73)
# draw(bob, dots, factor=76)
# draw(bob, dots, factor=79)
# draw(bob, dots, factor=80)
# draw(bob, dots, factor=86)
# draw(bob, dots, factor=91)
# draw(bob, dots, factor=99)

bob.hideturtle()
turtle.exitonclick()
