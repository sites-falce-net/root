import turtle

bob = turtle.Turtle()
bob.speed(10)


def polygon(trtl, sides, length):
    for i in range(sides):
        trtl.forward(length)
        trtl.left(360/sides)

def move(trtl, x, y):
    trtl.penup()
    trtl.goto(x, y)
    trtl.pendown()


for i in range(100):
    polygon(bob, 4, 100)
    bob.left(360/100)
    if i % 20 == 0:
        bob.color("red")
    else:
        bob.color("black")


# for i in range(500):
#     polygon(bob, 4, i*1.5)
#     bob.left(5)


# for i in range(200):
#   bob.forward(i)
#   bob.right(91)


# for i in range(100):
#     for j in range(4):
#         if j == 1 or j == 2:
#             bob.pendown()
#         else:
#             bob.penup()
#         bob.forward(100)
#         bob.left(90)
#     bob.left(360/100)




# size = 1
# for i in range(200):
#     for j in range(4):
#           # turtle.forward(i)
#           # turtle.forward(i + j)
#           turtle.forward(size)
#           turtle.left(90)
#           size = size + 1
#     turtle.left(10)

# for i in range(6):
#     polygon(bob, 6, 20)
#     bob.backward(20)
#     bob.left(60)


# for i in range(400):
#     bob.forward(i)
#     bob.left(121)

# for i in range(400):
#     bob.forward(i*2)
#     bob.left(119)




bob.hideturtle()
turtle.mainloop()
