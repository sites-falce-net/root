import turtle
import math

def polygon(trtl, sides, length):
    for i in range(sides):
        trtl.forward(length)
        trtl.left(360/sides)


def move(trtl, x, y):
    trtl.penup()
    trtl.goto(x, y)
    trtl.pendown()


bob = turtle.Turtle()
# bob.speed(10)

# move(bob, 0, 300)
# bob.goto(0, -300)
# move(bob, -300, 0)
# bob.goto(300, 0)

# for i in range(30):
#     move(bob, 0, 300 - 10 * i)
#     bob.goto(10 * i, 0)
# for i in range(30):
#     move(bob, 0, 300 - 10 * i)
#     bob.goto(-10 * i, 0)
# for i in range(30):
#     move(bob, 0, -300 + 10 * i)
#     bob.goto(10 * i, 0)
# for i in range(30):
#     move(bob, 0, -300 + 10 * i)
#     bob.goto(-10 * i, 0)

# def draw(trtl, length, steps):
#     offset = length / steps
#     for i in range(steps + 1):
#         trtl.goto(0, length - offset * i)
#         trtl.goto(offset * i, 0)
#         trtl.goto(0, -length + offset * i)
#         trtl.goto(-offset * i, 0)
# 
# 
# bob.color('green')
# bob.speed(10)
# draw(bob, 300, 50)

#
#
# L = 70
# l = 20
# x = -200
# y = 200
# r3 = math.sqrt(3)
#
# bob.pensize(3)
# for j in range(2):
#     move(bob, x, y)
#     for i in range(3):
#         move(bob, bob.xcor(), bob.ycor() - (L-l) * r3)
#         polygon(bob, 6, L)
#     x = x + (L-l) * 1.5
#     y = y - (L-l)/2*r3 if j%2==0 else y + (L-l)/2*r3

# for j in range(1):
#     for i in range(6):
#         polygon(bob, 6, 100)
#         bob.forward(50)
#         bob.right(60)
#     bob.forward(50)
#     bob.left(120)

# bob.hideturtle()
# turtle.exitonclick()


# for j in range(1):
#     for i in range(60):
#         polygon(bob, 6, 100)
#         bob.left(30)

for j in range(1):
    for i in range(60):
        polygon(bob, 3, 100)
        bob.left(10)

