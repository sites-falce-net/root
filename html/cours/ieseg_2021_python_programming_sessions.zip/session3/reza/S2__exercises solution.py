import turtle
from utils import square, polygon

bob = turtle.Turtle()
bob.speed(0)

# 360//5 == int(360/5) = 72
# 360/5 = 72.0


# Q1
# for i in range(360//5):
#     square(bob, 100)
#     bob.left(5)


# Q2
# for i in range(1000):
#     square(bob, i*2)
#     bob.left(5)


for i in range(300):
    bob.forward(i*2)
    bob.left(121)
    # bob.left(140)


# for i in range(200):
#     bob.forward(i)
#     bob.right(91)



turtle.mainloop()
