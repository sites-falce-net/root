import zipfile
from docx import oxml, opc
from docx.enum.dml import MSO_THEME_COLOR_INDEX
import tkinter as tk
from tkinter import filedialog
from hashlib import blake2b


def show_openfile_dialog(multiple=False):
    root = tk.Tk()
    root.withdraw()
    if multiple:
        paths = filedialog.askopenfilenames()
    else:
        paths = filedialog.askopenfilename()
    root.update()
    return paths


def consolidate_dicts(*dicts):
    consolited = {}
    for d in dicts:
        for k, v in d.items():
            msg = "Values of the key '{}' are not of the same type: {} & {}"
            msg = msg.format(k, type(consolited.get(k, v)), type(v))
                       
            if type(v) is dict:
                assert type(consolited.get(k, {})) is dict, msg
                consolited[k] = consolidate_dicts(consolited.get(k, {}), v)
            elif type(v) is list:
                consolited[k] = [*consolited.get(k, []), *v]
            elif type(v) is tuple:
                assert type(consolited.get(k, ())) is tuple, msg
                consolited[k] = (*consolited.get(k, ()), *v)
            elif type(v) is set:
                assert type(consolited.get(k, set())) is set, msg
                consolited[k] = {*consolited.get(k, set()), *v}
            else:
                consolited[k] = (*consolited.get(k, ()), v)

    return consolited


def add_hyperlink(paragraph, link_to, text, is_external=True, is_underlined=False):
    part = paragraph.part   
    hyperlink = oxml.shared.OxmlElement('w:hyperlink')
    
    if is_external:
        r_id = part.relate_to(link_to, 
            opc.constants.RELATIONSHIP_TYPE.HYPERLINK, 
            is_external= is_external)

        hyperlink.set(oxml.shared.qn('r:id'), r_id, )
    else:
        hyperlink.set(oxml.shared.qn('w:anchor'), link_to, )

    new_run = oxml.shared.OxmlElement('w:r')
    rPr = oxml.shared.OxmlElement('w:rPr')

    new_run.append(rPr)
    new_run.text = text
    hyperlink.append(new_run)

    if is_underlined:
        r = paragraph.add_run()
        r._r.append (hyperlink)
        r.font.color.theme_color = MSO_THEME_COLOR_INDEX.HYPERLINK
        r.font.underline = True
    else:
        paragraph._p.append(hyperlink)

def remove_bookmark(run):
    for el in run._parent._element.xpath('w:bookmarkStart'):
        el.getparent().remove(el)

    for el in run._parent._element.xpath('w:bookmarkEnd'):
        el.getparent().remove(el)
    

def add_bookmark(run, bookmark_name):
    ''' Adds a word bookmark to a run '''
    tag = run._r
    start = oxml.shared.OxmlElement('w:bookmarkStart')
    start.set(oxml.ns.qn('w:id'), '0')
    start.set(oxml.ns.qn('w:name'), bookmark_name)
    tag.addprevious(start)
    # text = oxml.OxmlElement('w:r')
    # tag.append(text)
    end = oxml.shared.OxmlElement('w:bookmarkEnd')
    end.set(oxml.ns.qn('w:id'), '0')
    tag.addnext(end)
    
    return run




def unzip_word_file(path):
    unzipped = zipfile.ZipFile(path)
    document = unzipped.read('word/document.xml')
    try:
        comments = unzipped.read('word/comments.xml')
    except KeyError:
        comments = {}
    
    unzipped.close()
    return {'document': document, 'comments': comments}


def has_deep_key(obj, key):
    assert type(obj) is dict
    for k, v  in obj.items():
        if k == key:
            return v
        elif type(v) is dict:
            found = has_deep_key(v, key) 
            if found is not None:
                return found


def _hash(text, use_length=500, digest_size=8):
    b = bytes(text[:use_length], encoding='utf-8')
    return blake2b(b, digest_size=digest_size).hexdigest()


def get_paragraph(doc, text, style):
    for i,p in enumerate(doc.paragraphs):
        if p.style.name == style and p.full_text == text:
            return i,p
    return None, None


def insert_paragraph(doc, paragraph):
    doc._body._body._insert_p(paragraph._p)


def delete_paragraph(paragraph):
    p = paragraph._element
    p.getparent().remove(p)
    p._p = p._element = None


def delete_all_paragraphs(doc):
    for p in doc.paragraphs + doc.tables:
        delete_paragraph(p)


def delete_all_bookmarks(doc):
    for p in doc.paragraphs:
        for r in p.runs:
            remove_bookmark(r)