from openpyxl import load_workbook
from docx import Document
from pathlib import Path
from utils import show_openfile_dialog

filename = show_openfile_dialog()

first_question_column = "R"
last_question_column = "AT"
ids_column = "AU"


def read_survey_file(filename):
    workbook = load_workbook(filename)
    sheet = workbook.active

    count_rows = len(sheet[first_question_column])
    q_range = sheet['{}2:{}2'.format(first_question_column, last_question_column)]
    r_range = sheet['{}3:{}{}'.format(first_question_column, ids_column, count_rows)]

    questions = [c.value for r in q_range for c in r]
    responses = {r[-1].value: [c.value for c in r[:-1]] for r in r_range}

    return questions, responses


def write_to_Word_per_respondant(questions, responses, per="respondant"):
    document = Document()

    for id in responses.keys():
        document.add_paragraph(
            'Respondant ID: {}'.format(id), 
            style="Heading 1"
        )

        for i, question in enumerate(questions):
            document.add_paragraph(
                '{}) {}'.format(i+1, question),
                style="Heading 2"
            )
        
            document.add_paragraph(
                str(responses[id][i]),
                style='Quote'
            )

        document.add_page_break()

    _filename = '{} per respondant.docx'.format(filename.split('.')[0])
    document.save(_filename)


def write_to_word_per_question(questions, responses):
    document = Document()

    for i, question in enumerate(questions):
        document.add_paragraph(
            '{}) {}'.format(i+1, question), 
            style="Heading 1"
        )

        for id in responses.keys():
            document.add_paragraph(
                '{}: {}'.format(id, responses[id][i]),
                style='Quote'
            )
    
        document.add_page_break()

    _filename = '{} per question.docx'.format(filename.split('.')[0])
    document.save(_filename)


questions, responses = read_survey_file(filename)
write_to_Word_per_respondant(questions, responses)
write_to_word_per_question(questions, responses)
