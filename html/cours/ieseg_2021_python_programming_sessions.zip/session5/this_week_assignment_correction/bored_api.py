import requests

def get_activity(nb_participants=None, type_=None):
    ...
    """
    type_ has to be in the list: ["education", "recreational", "social",
    "diy", "charity", "cooking", "relaxation", "music", "busywork"]
    participants is an int
    """
    base_url = "http://www.boredapi.com/api/activity/"
    payload = {}
    if type_:
        payload['type'] = type_
    if nb_participants:
        payload['participants'] = nb_participants
    r = requests.get(base_url, params=payload)
    json_response = r.json()
    print("[debug] requested url: {}".format(r.url))

    if "error" in json_response:
        print("[warning] {}, {}".format(r.json()["error"], payload))
        return []
    
    return json_response["activity"]


def get_activities(nb_activities, nb_participants, type_=None):
    activities = []
    for _ in range(nb_activities):
        activity = get_activity(nb_participants, type_)
        print("[debug] {}".format(activity))
        activities.append(activity) # we can have duplicated activities. How can we solve that?
    return activities


def get_solo_activities(nb_activities=30):
    return get_activities(nb_activities, 1)

def get_duo_activities(nb_activities=10):
    return get_activities(nb_activities, 2)

def format_activities(activities):
    for activity in activities:
        print(activity)
        
format_activities(get_solo_activities())