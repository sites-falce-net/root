import requests
import datetime

MAPQUEST_API_KEY="hAGwKKrBmQIiqpaKQfZ0EgaGPyVy3EYD"

def get_weather(latitude, longitude):
    base_url = "http://www.7timer.info/bin/api.pl"
    payload = {"product": "civillight", "output": "json", "lat": latitude, "lon": longitude}
    r = requests.get(base_url, payload)
    print("[debug] {}".format(r.url))
    return r.json()

def get_latlon(adress):
    payload={"key": MAPQUEST_API_KEY, "location": adress}
    r = requests.get("http://open.mapquestapi.com/geocoding/v1/address", payload)
    return r.json()["results"][0]["locations"][0]["latLng"]



def format_weather(adress, latlon, weather):
    print(f"Weather for {adress} ({latlon})")
    for data in weather["dataseries"]:
        date = datetime.datetime.strptime(str(data['date']), '%Y%m%d')
        print(f"   {date.strftime('%A (%d/%m)'):>18}: {data['weather']:<10} -- temperature between {data['temp2m']['min']:>2} and {data['temp2m']['max']:<2} °C")


adress = "Lille,FR"    
latlon = get_latlon(adress)
weather = get_weather(latlon["lat"], latlon["lng"])
format_weather(adress, latlon, weather)