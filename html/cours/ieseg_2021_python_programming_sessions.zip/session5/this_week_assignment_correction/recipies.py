import requests

def get_recipe(ingredients):
    base_url = "http://www.recipepuppy.com/api/"
    payload = {"i": ingredients}
    r = requests.get(base_url, payload)
    print("[debug] {}".format(r.url))
    return r.json()["results"]

def format_recipies(recipies):
    for recipe in recipies:
        print("{}  (more infos on {})".format(recipe["title"].strip(), recipe["href"]))
        print("Ingredients list:")
        for ingredient in recipe["ingredients"].split(","):
            print("  * {}".format(ingredient.strip()))
        print("----------")


format_recipies(get_recipe(["salad greens"]))