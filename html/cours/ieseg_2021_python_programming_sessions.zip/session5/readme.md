# Introduction to API and datastructures

## Duration 

2h

## Program for the week

* consolidate session 4 
* consolidate iteration and lists 
* creation of some word reports

## Quizz

No quizz this week

## Live Coding 

* manipulate lists (idexation, slicing, iteration on items using for loops)
* manipulate dicts 
* extract some data from a web API

## Exercice for next week 

* modify the code to get the activities from last week exercice to get 10 unique activities => for to while loop 
* generate recepies from a recipyAPI (recipepuppy) and output them as text => request an API and manipulate it's data, string formatting

## Feedback 

The students still struggle with some basics (confusion between for and while loops, but the iteration concept seems ok). 