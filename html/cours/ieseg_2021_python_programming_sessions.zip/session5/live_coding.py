numbers = list(range(0, 101))
print(type(numbers))

# persons_in_the_room = [
#     "Malek", "Matthieu", "Camille",
#     "Helen", "Cassandre", "Félix",
#     "Benjamin", "Arthur", "Jonathan",
#     "Adrien", "Thanh Mai",
# ]
# 
# print("all the people", persons_in_the_room)
# print("number of people", len(persons_in_the_room))
# print("some people", persons_in_the_room[:4])
# print(persons_in_the_room[7], persons_in_the_room[0])


# for index in range(len(persons_in_the_room)):
#     person = persons_in_the_room[index]
#     print(person)
#     
# for person in persons_in_the_room:
#     print(person)

# for number in range(101):
#     print(number)
    

### question 3 and 4
# pi = 3.14
# def surface(radius):
#     return pi * radius ** 2
# 
# dollar_per_sq_m = 10
# print("I own", surface(10) * dollar_per_sq_m)

## question 5 
# def surface(radius):
#     return pi * radius ** 2
# 
# pi = 3.14
# print(surface(10))

## question 6 
# def surface(size_of_circle):
#     pi = 5
#     return pi * size_of_circle ** 2
# 
# pi = 3.14
# print(surface(10))
# 


## question 7
# pi = 3.14
# def surface(radius):
#     pi = 5
#     return pi * radius ** 2
# 
# print(pi)
# print(surface(10))
# print(pi)


## what we have seen in the first 1h 
# correction of number from 0 to 100
# how to write lists
# slicing
# how to get the size of a list : the len function
# understanding the none type
# discussed the scope of variables in functions

my_first_dict = {"name": "Matthieu", "familly name": "Falce"}
oxford_dictionnary = {"a word": "definition"}
print(my_first_dict["name"])


import requests


# r = requests.get("http://www.boredapi.com/api/activity/")
# json_response = r.json()
# print(json_response)
# print(type(json_response))
# print(json_response["activity"])



# for index in range(11):
#     r = requests.get("http://www.boredapi.com/api/activity/")
#     json_response = r.json()
#     print(json_response["activity"])


activities = []
activities.append("Shop at support your local farmers market")

print("shop at support your local farmers market" in activities)
print("toto" in activities)
print(activities)


# 
# 
# url = "http://www.boredapi.com/api/activity"
# print(url)
# individual_activities = {"participants": 1}
# for _ in range(11):
#     r = requests.get(url, params=individual_activities)
#     # print(r.url)
#     json_response = r.json()
#     print(json_response["activity"], json_response["key"])
# 
# 
# 
# 
