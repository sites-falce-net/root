# Week 4: Introduction to data structures

## Duration 

2h

## Program for the week

* continue on functions 
* talk about the scope of functions (LEGB)
* install a module (using thonny)
* web APIs and datatructures (lists, dicts)
    * presentation of the concept of webAPI
    * concept of JSON 
    * manipulate data structures (list, dicts)

## Quizz

7 questions this week, separated in 2 parts : 
1. write some code to implement the fizzbuzz algorithm
2. find the correct result of a piece of code (different variables scope) 

## Live coding 

* correction of the quizz 
* install requests
* query a webpage using requests

## Exercice for next week 

* retake the quizz
* use a for loop and the range function to write all the 100 first numbers
* use an API (boredapi.com) to extract some activities

## Feedback 

A lot of students didn't succeed to implement the fizzbuzz code. Some of them still struggle to get the syntax right.

Students struggle to use `for` loops, they only use `while` loops => they don't know about the `range` function.

This week was quite dense. 
Very magistral, the students didn't practice much (except in the quiz which was failed by most of them)

I don't think they understand the JSON concept.

I don't remember, but I think we didn't finish this week lessons on time / see all what was planned. 