"""
toto = 2

def f(toto):
    print(toto)
    toto = 4
    print(toto)
    return toto

yoda = f(3)
print(toto)
print(yoda)

for number in range(101):
    if number % 4 == 0 and number % 7 == 0:
        print("spamegg")
    elif number % 4 == 0:
        print("spam")
    elif number % 7 == 0:
        print("egg")
    else:
        print(number)
"""

import requests

r = requests.get("https://www.boredapi.com/api/activity")
print(r.json())