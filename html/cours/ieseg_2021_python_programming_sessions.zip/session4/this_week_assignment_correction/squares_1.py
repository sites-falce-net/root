from colorsys import hsv_to_rgb
import turtle


bob = turtle.Turtle()
bob.speed(0)

def polygon(trtl, sides, length):
    """A function that draws a regular polygon.
    Given a turtle, moves it to have a polygon with the
    correct number of sides and length
    """
    for _ in range(sides):
        trtl.forward(length)
        trtl.left(360/sides)

def move(trtl, x, y):
    """Moves the turtle at a specific coordinate.
    """
    trtl.penup()
    trtl.goto(x, y)
    trtl.pendown()

def squares_a():
    """Draws the assignment a.
    We draw a square and slightly turn the turtle then draw a new square.
    We repeat this the necessary number of times to
    return to the original position. 
    """
    for i in range(100):
        color = hsv_to_rgb(i/100, 0.75, 0.75)
        bob.pencolor("black")
        bob.fillcolor(color)
        bob.begin_fill()
        polygon(bob, 4, 100)
        bob.end_fill()
        bob.left(360/100)


def squares_b():
    """Draws the assignment b.
    We draw some square, like in squares_a.
    But we increase the size of the sides from one square to the next.
    """
    for i in range(500):
        polygon(bob, 4, i*1.5)
        bob.left(5)


def quasi_triangles_c():
    """Draws the assignment c.
    There is only one polygon in this one.
    We don't close the triangle as we 
    """
    for i in range(400):
        bob.forward(i)
        bob.left(121)

def quasi_squares():
    """Bonus, same as quasi_tirangle_c but with squares
    """
    for i in range(200):
        bob.forward(i)
        bob.right(91)
  
def half_squares():
    """Bonus, similar to squares_a, but we
    only draw the 2 first sides of a square.
    """
    for _ in range(100):
        for j in range(4):
            if j == 1 or j == 2:
                bob.pendown()
            else:
                bob.penup()
            bob.forward(100)
            bob.left(90)
        bob.left(360/100)
        
        
squares_a()
# squares_b()
# quasi_triangles_c()