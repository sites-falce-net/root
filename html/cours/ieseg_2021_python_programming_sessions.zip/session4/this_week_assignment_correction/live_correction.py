import turtle

my_turtle = turtle.Turtle()
my_turtle.speed(0)  # speed up drawing process

def draw_1_square(a_turtle, width_of_square):
    for _ in range(4):
        a_turtle.forward(width_of_square)
        a_turtle.left(90)


def draw_square_1():
    constant_angle_for_turning_left = 15
    max_time = 360 / constant_angle_for_turning_left
    for step in range(int(max_time)):
        draw_1_square(my_turtle, 100)
        my_turtle.left(constant_angle_for_turning_left)



def draw_square_2():
    constant_angle_for_turning_left = 10
    for step in range(50):
        draw_1_square(my_turtle, 100 * step *0.05)
        my_turtle.left(constant_angle_for_turning_left)


def draw_triangles_3():
    for step in range(120):
        my_turtle.forward(100 * step *0.05)
        my_turtle.left(121)



# draw_square_1()
# draw_square_2()
# draw_triangles_3()
