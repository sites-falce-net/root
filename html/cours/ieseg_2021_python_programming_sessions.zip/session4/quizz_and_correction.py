#####################
# question 1

# Write a code that implements the following algorithm

## For all the numbers between 0 and 100;
## If the number is divisible by 4, write "spam"
## If the number is divisible by 7, write "egg"
## If the number is divisible by 7 and 4, "spamegg"
## If none of the previous conditions are met, print the number
#####################
def spam_egg():
    for number in range(1, 101):
        if number % 4 == 0 and number % 7 == 0:
            print("spamegg")
        elif number % 4 == 0:
            print("spam")
        elif number % 7 == 0:
            print("egg")
        else:
            print(number)

def spam_egg_2():
    for number in range(1, 101):
        res = ""
        if number % 4 == 0:
            res += "fizz"
        elif number % 7 == 0:
            res += "buzz"
        if not res:
            res = str(number)
        print(res)

##################
# Question 2
# From now, we assume all codes are independants
# (only the code displayed exists in the interpreter)

# What is the result of this code? Why?
##################

pi = 3.14
def surface(radius):
    return pi * radius ** 2

# answer
## Does nothing, the function is only defined, and not executed


##################
# Question 3
# From now, we assume all codes are independants
# (only the code displayed exists in the interpreter)

# What is the result of this code? Why?
##################
pi = 3.14
def surface(radius):
    res = pi * radius ** 2

print(surface(10))

# answer
## Prints None, the value is not returned


##################
# Question 4
# From now, we assume all codes are independants
# (only the code displayed exists in the interpreter)

# What is the result of this code? Why?
##################
pi = 3.14
def surface(radius):
    return pi * radius ** 2

print(surface(10))

# answer
## Prints 314 the value is computed in the
## function, returned and printed


##################
# Question 5
# From now, we assume all codes are independants
# (only the code displayed exists in the interpreter)

# What is the result of this code? Why?
##################

def surface(radius):
    return pi * radius ** 2

pi = 3.14
print(surface(10))

# answer
# prints 314. The variable needs to exist in the global
# space when the function is executed, no need to define it before



##################
# Question 6
# From now, we assume all codes are independants
# (only the code displayed exists in the interpreter)

# What is the result of this code? Why?
##################

def surface(radius):
    pi = 5
    return pi * radius ** 2

pi = 3.14
print(surface(10))

# answer
# prints 500. The scope of functions is the following
# (if the name doesn't exist in one level, we go deeper):
# * locals to the functions
# * enclosed
# * globals
# * builtins
# The local "pi" hides the global "pi"


##################
# Question 7
# From now, we assume all codes are independants
# (only the code displayed exists in the interpreter)

# What is the result of this code? Why?
##################

pi = 3.14
def surface(radius):
    pi = 5
    return pi * radius ** 2

print(pi)
surface(10)
print(pi)

# answer
# prints 3.14 then executes the function (which prints nothing) and then prints 3.14.
# 2 variables are named pi :
# * the one in the "surface" function is "private" and local to the function
# * the global one is not modified 