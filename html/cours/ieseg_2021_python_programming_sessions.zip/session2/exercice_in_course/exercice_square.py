"""
Session 1 live coding.
Subjets : variables / conditionnals / iteration

Projects : 
 * draw a square => variables / turtle API 
 * draw a colorfull square => turtle API / variable types
 * draw a magical colorful square (random colors) => variables : namming -- printing / conditionnals / random numbers
 * draw a pentagon (5 sides shape) => variables and introductions to iteration to remove duplicated code
"""

import turtle
import random

bob = turtle.Turtle()
# what is bob ? a variable. Variables are named and
# the names should be targetted to be understood by humans

# where can I find informations on this variable ?
# on the official docs https://docs.python.org/3/library/turtle.html

# 1. let's draw a square
"""
bob.forward(100)
bob.left(90)

bob.forward(100)
bob.left(90)

bob.forward(100)
bob.left(90)

bob.forward(100)
bob.left(90)
"""


# 2. let's draw a colorfull square
"""
bob.color("blue")
bob.forward(100)
bob.left(90)

bob.color("green")
bob.forward(100)
bob.left(90)

bob.color("red")
bob.forward(100)
bob.left(90)

bob.color("black")
bob.forward(100)
bob.left(90)
"""

# 3. let's draw a magical colorfull square
"""
random_number = random.random()
if random_number < 0.5:
    print("number is", random_number, "so it's blue")
    bob.color("blue")
else:
    print("number is", random_number, "so it's red")
    bob.color("red")
bob.forward(100)
bob.left(90)

random_number = random.random()
if random_number < 0.5:
    print("number is", random_number, "so it's blue")
    bob.color("blue")
else:
    print("number is", random_number, "so it's red")
    bob.color("red")
bob.forward(100)
bob.left(90)

random_number = random.random()
if random_number < 0.5:
    bob.color("blue")
else:
    bob.color("red")
bob.forward(100)
bob.left(90)

random_number = random.random()
if random_number < 0.5:
    bob.color("blue")
else:
    bob.color("red")
bob.forward(100)
bob.left(90)
"""

# Draw a pentagon (factorize code with iteration)

side_numbers = 40
for side_number in range(side_numbers):
    random_number = random.random()
    if random_number < 0.5:
        print("number is", round(random_number, 2), "so it's blue")
        bob.color("blue")
    else:
        print("number is", round(random_number, 2), "so it's red")
        bob.color("red")
    bob.forward(20)
    bob.left(360 / side_numbers)
