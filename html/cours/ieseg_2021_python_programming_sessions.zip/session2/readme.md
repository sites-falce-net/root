# Introduction to python

## Duration 

2h

## Program for the week

* quizz + correction
* present the basic concepts in python
    * variables
    * blocs (conditionnals + iterations)

## Quizz

Extract the algorithm behind "fizzbuzz"

## Live Coding 

* use turtle to draw a square
* search documentation to find the method to change the pen color
* use conditionnals to change the color (draw a random number)
* draw a pentagon => intro to iteration 

## Exercice for next week 

Draw a house using "turtle" then add colors.

Concepts:
    * problem solving
    * search the documentation to find the correct functions to use

The exercice has to be submitted on replit.

## Feedback 

Students are confused that they need to search things on the internet. 
I am not sure all of them clicked with the concept of algorithms. 