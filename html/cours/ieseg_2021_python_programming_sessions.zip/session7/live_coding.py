import requests
from bs4 import BeautifulSoup


url_to_scrape = "http://books.toscrape.com/catalogue/category/books/horror_31/index.html"

# we download the page
page = requests.get(url_to_scrape)

# we parse (transform to something easy to manipulate)
# the HTML content of the webpage with beautiful soup
soup = BeautifulSoup(page.content, 'html.parser')
# HTML is like a tree (think a genealogical tree) with all the
# elements being parents / children / siblings,
# we need to find the correct node and BS make that easy.
# To understand this deeply, you need to follow a HTML / CSS / web course,
# it's outside the scope of this course

# we identify the elements containing the price
# all the books item have the same structure, in the dev tools we
# realize the prices are in paragraphs ("p") with class "price_color"
price_paragraphs = soup.findAll('p', class_='price_color')

# prices contains all the paragraphs with prices,
# we need to extract the text of each paragraph and remove the
# currency (using slicing on the string)
prices = []
for price_paragraph in price_paragraphs:
    prices.append(float(price_paragraphs.text[1:]))
    
print(extracted_prices)
