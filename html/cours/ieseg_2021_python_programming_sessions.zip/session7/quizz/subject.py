import random
import requests
import csv

def fizz_buzz_rule(n):
    res = ""
    if n % 3 == 0:
        res += "fizz"
    if n % 5 == 0:
        res += "buzz"
    if not res:
        res = str(n)
    return n, res

def data_1():
    return random.randint(1, 100)

def data_2():
    url = "http://www.randomnumberapi.com/api/v1.0/random?min=1&max=100&count=1"
    return requests.get(url).json()[0]

def output_1(res):
    for (n, r) in res:
        print("{} is {}".format(n, r))
        
def output_2(res):
    with open("output.csv", "w", newline='') as f:
        writer = csv.writer(f)
        for row in res:
            writer.writerow(row)


def main():
    data = data_1()
    res = []
    for n in range(data):
        res.append(fizz_buzz_rule(n))
    output_2(res)