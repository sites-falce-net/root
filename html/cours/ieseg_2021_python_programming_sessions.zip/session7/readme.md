# Introduction to webscrapping

## Duration 

2h

## Program for the week

* presentation of the data pipeline (input, data manipulation, output)
* introduction to webscrapping 
    * download a webpage
    * extract element from HTML
* use `beautifulsoup` to extract data from HTML

## Quizz

No quizz this week

## Exercice for next week 

Scrape a website (books.toscrape.com) to extract some data. 
They will need a "price.csv" file, that is generated using the code in `prepair_this_week_assignment/question_change_prices.py`

## Feedback 

The students prefered to see the webscrapping to the data analysis, which is surprising. 