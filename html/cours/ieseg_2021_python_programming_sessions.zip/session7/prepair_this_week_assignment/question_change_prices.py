import requests
import csv
import random
from bs4 import BeautifulSoup


url_to_scrape = "http://books.toscrape.com/catalogue/category/books/horror_31/index.html"
page = requests.get(url_to_scrape)
soup = BeautifulSoup(page.content, 'html.parser')
articles = soup.findAll('article')

infos = []
for article in articles:
    original_price = float(article.find("p", class_="price_color").text[1:])
    res = {
        "title": article.h3.a.get("title"),
        "original_price": original_price,
        "amazon_price": round(random.normalvariate(original_price, original_price/10), 2)
    }
    infos.append(res)

random.shuffle(infos)

with open("prices_all.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, infos[0].keys())
    writer.writeheader()
    writer.writerows(infos)

with open("prices.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, ["title", "amazon_price"], extrasaction='ignore')
    writer.writeheader()
    writer.writerows(infos)