import json
import requests
import generate_reports

MAPQUEST_API_KEY="hAGwKKrBmQIiqpaKQfZ0EgaGPyVy3EYD"

## input functions
def fake_weather_data():
    """Load the weather data from the local JSON file.
    This is useful to speed up the development. 
    """
    return json.load(open("data.json"))


def internet_weather_data():
    """Load the weather data from the internet.
    This is useful to get the real time data. 
    """
    adresses = get_adresses()
    data = prepair_data(adresses)
    return data

def get_adresses():
    """Load the adresses from a python list
    """
    return ["Lille,FR", "Paris, FR", "Monaco, MC", "New York, USA"]


def get_adresses_from_file():
    """Load the adresses from a text file (an adress per line). 
    """
    with open("./adress.txt") as f:
        adresses  = f.readlines()
    return adresses


## data manipulation
def get_weather(latitude, longitude):
    """Get the weather for the 7timer api using civilligt type
    We need the latitude and longitude for the point we want to forecast
    We return the JSON from the API
    """
    base_url = "http://www.7timer.info/bin/api.pl"
    payload = {"product": "civillight", "output": "json", "lat": latitude, "lon": longitude}
    r = requests.get(base_url, payload)
    print("[debug] {}".format(r.url))
    return r.json()

def get_latlon(adress):
    """Get the latitude and longitude from an adress (geocoding) using mapquest API
    We need the adress of a place
    We return the latitude and longitude
    """
    payload={"key": MAPQUEST_API_KEY, "location": adress}
    r = requests.get("http://open.mapquestapi.com/geocoding/v1/address", payload)
    return r.json()["results"][0]["locations"][0]["latLng"]


def prepair_data(adresses):
    """Prepair the data to be in the correct shape
    we want the data to be a list of dictionnaries
        {
            "city": "Lille",
            "coords": (latlon),
            "weather": the weather for the 7 next days in that city
        }
    We return a list of dictionnaries 
    """
    res = []
    for adress in adresses:
        latlon = get_latlon(adress)
        weather = get_weather(latlon["lat"], latlon["lng"])
        tmp = {
            "city": adress,
            "coords": latlon,
            "weather": weather["dataseries"],
        }
        res.append(tmp)
    return res

## output functions

def dump_json(city_datas):
    """Save (dumps) the forecast data in a local JSON file.
    To use with load_json
    """
    json.dump(city_datas, open("data.json", "w"))


## pipeline
def main():
    data = internet_weather_data()
    
    generate_reports.word(data)
    generate_reports.powerpoint(data)
    generate_reports.excel(data)
    generate_reports.CSV(data)
    generate_reports.console(data)
    
    
main()