import datetime
import csv
import sys

from docx import Document
from pptx import Presentation
from pptx.util import Pt
import xlsxwriter


def console(city_datas):
    """Print the results in the console
    """
    for city_data in city_datas:
        adress = city_data["city"]
        latlon = city_data["coords"]
        weather = city_data["weather"]
        
        print(f"Weather for {adress} ({latlon})")
        for data in weather:
            date = datetime.datetime.strptime(str(data['date']), '%Y%m%d')
            print(f"   {date.strftime('%A (%d/%m)'):>18}: {data['weather']:<10} -- temperature between {data['temp2m']['min']:>2} and {data['temp2m']['max']:<2} °C")
        print("")


def text_file(city_datas):
    """Output the forecast in a text file
    This one is tricky, we change the output of print to be in a
    text file and call the format_weather_console
    
    Source: https://stackoverflow.com/questions/7152762/how-to-redirect-print-output-to-a-file-using-python
    """
    orig_stdout = sys.stdout
    sys.stdout = open("forecast_report.txt", "w")
    format_weather_console(city_datas)
    sys.stdout.close()
    sys.stdout = orig_stdout


def word(city_datas):
    """Create a report in the docx format.
    """
    document = Document()
    document.add_heading('Weather forecast', 0)
    
    for city_data in city_datas:
        adress = city_data["city"]
        latlon = city_data["coords"]
        weather = city_data["weather"]

        document.add_heading(f"Weather for {adress} ({latlon})", level=1)
        document.add_paragraph("")
        table = document.add_table(rows=1, cols=4)
        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = 'Date'
        hdr_cells[1].text = 'Weather'
        hdr_cells[2].text = 'Temp Min'
        hdr_cells[3].text = 'Temp Max'
        
        for data in weather:
            date = datetime.datetime.strptime(str(data['date']), '%Y%m%d')
            formatted_date = date.strftime('%A (%d/%m)')
            row_cells = table.add_row().cells            
            row_cells[0].text = formatted_date
            row_cells[1].text = data['weather']
            row_cells[2].text = str(data['temp2m']['min'])
            row_cells[3].text = str(data['temp2m']['max'])   
        document.add_page_break()
    document.save('weather_report.docx')


def powerpoint(city_datas):
    """Create a report in the powerpoint (pptx) format.
    """
    prs = Presentation()
    
    title_slide_layout = prs.slide_layouts[0]
    bullet_slide_layout = prs.slide_layouts[1]
    
    slide = prs.slides.add_slide(title_slide_layout)
    slide.shapes.title.text = "Weather Forecast Report"
    
    for city_data in city_datas:
        adress = city_data["city"]
        latlon = city_data["coords"]
        weather = city_data["weather"]
        
        slide = prs.slides.add_slide(bullet_slide_layout)
        slide.shapes.title.text = f"Weather for {adress} \n ({latlon})"

        body_shape = slide.shapes.placeholders[1]
        tf = body_shape.text_frame
        for data in weather:
            date = datetime.datetime.strptime(str(data['date']), '%Y%m%d')
            formatted_date = date.strftime('%A (%d/%m)')
            
            p = tf.add_paragraph()
            font = p.font
            font.name = 'Calibri'
            font.size = Pt(16)

            p.text = formatted_date
            p.level = 1        

            p = tf.add_paragraph()
            font = p.font
            font.name = 'Calibri'
            font.size = Pt(14)

            p.text = f"{data['weather']}: {data['temp2m']['min']}°C / {data['temp2m']['max']}°C"
            p.level = 2        

    prs.save('weather_report.pptx')


def excel(city_datas):
    """Create a report in the excel (xlsx) format.
    """
    for city_data in city_datas:
        city = city_data["city"]
        latlon = city_data["coords"]
        weather = city_data["weather"]

        workbook = xlsxwriter.Workbook(f'report_{city}.xlsx')
        worksheet = workbook.add_worksheet()
        
        worksheet.write(0, 0, "date")
        worksheet.write(0, 1, "weather")
        worksheet.write(0, 2, 'Temp min')
        worksheet.write(0, 3, 'Temp max')
        
        row = 1
        col = 0
        # Iterate over the data and write it out row by row.
        for data in weather:
            date = datetime.datetime.strptime(str(data['date']), '%Y%m%d')
            formatted_date = date.strftime('%A (%d/%m)')            
            worksheet.write(row, col, formatted_date)
            worksheet.write(row, col + 1, data['weather'])
            worksheet.write(row, col + 2, data['temp2m']['min'])
            worksheet.write(row, col + 3, data['temp2m']['max'])
            row += 1
        workbook.close()


def CSV(city_datas):
    """Create a report in the text (CSV) format.
    Warning: the name should be in uppercase to prevent a clash with the csv module.
    """
    for city_data in city_datas:
        city = city_data["city"]
        latlon = city_data["coords"]
        weather = city_data["weather"]
    
        rows = []
        for data in weather:
            date = datetime.datetime.strptime(str(data['date']), '%Y%m%d')
            formatted_date = date.strftime('%A (%d/%m)')
            rows.append(
                {
                    "date": formatted_date,
                    "weather": data['weather'],
                    "temp min": data['temp2m']['min'],
                    "temp max": data['temp2m']['max'],                        
                }
            )
            
        with open(f"report_{city}.csv", "w", newline="") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)