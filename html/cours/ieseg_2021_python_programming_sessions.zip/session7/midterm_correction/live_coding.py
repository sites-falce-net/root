import output_powerpoint

# 1) INPUT: take some data (file, API)
weather_infos = [{"date":"04/03", "weather":"sunny"}, {"date":"05/03", "weather":"sunny"}, {"date":"06/03", "weather":"sunny"}]

# 2) DATA MANIPULATION: adapt the data to answer the questions you want


# 3) OUTPUT: create the reports 
#output_powerpoint.generate_report(weather_infos)


f = open("my_file.txt", "w")
f.write("toto")
f.close()


f = open("my_file.pptx", "w")
f.write("toto")
f.close()










