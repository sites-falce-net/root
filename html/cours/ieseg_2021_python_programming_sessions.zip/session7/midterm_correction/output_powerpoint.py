from pptx import Presentation


prs = Presentation()

def title_page():
    title_slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]

    title.text = "Weather report"
    subtitle.text = "For the cities: New York, Lille, Monaco, Paris"



def one_city_page(city_name, weather_infos):
    bullet_slide_layout = prs.slide_layouts[1]

    slide = prs.slides.add_slide(bullet_slide_layout)
    shapes = slide.shapes

    title_shape = shapes.title
    body_shape = shapes.placeholders[1]

    title_shape.text = f'Weather for city: {city_name}'

    tf = body_shape.text_frame
    tf.text = ''

    for weather_info in weather_infos:
        p = tf.add_paragraph()
        p.text = f'{weather_info["date"]} : {weather_info["weather"]}'
        p.level = 1


def generate_report():
    title_page()
    one_city_page("Lille", weather_infos)
    one_city_page("Paris", weather_infos)
    prs.save('test.pptx')