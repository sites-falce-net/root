default_app_config = 'news.apps.NewsConfig'
