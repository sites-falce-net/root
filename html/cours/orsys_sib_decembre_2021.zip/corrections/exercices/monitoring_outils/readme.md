# Outils à installer 

* jmeter : mesure les performances d'un site web
* elk : avec docker 
    * filebeat
    * metricsbeat
    * apm
* jeager
* prometheus


# Biblio

* comparaison (metric, APM, opentracing): https://sysdig.com/blog/how-to-instrument-code-custom-metrics-vs-apm-vs-opentracing/

* installer ELK : 
    * https://www.elastic.co/guide/en/elasticsearch/reference/current/rpm.html
    * https://computingforgeeks.com/how-to-install-elk-stack-on-centos-fedora/
* tracing / APM : https://medium.com/opentracing/the-difference-between-tracing-tracing-and-tracing-84b49b2d54ea
* jaeger : 
    * https://www.jaegertracing.io/download/
    * https://www.jaegertracing.io/docs/1.16/frontend-ui/
    * https://medium.com/opentracing/take-opentracing-for-a-hotrod-ride-f6e3141f7941

* elastic RUM : Elastic APM Real User Monitoring

* promethéus (pull / push) : 
    * If the monitoring system needs to know the desired state of the world anyway, then a push-based approach actually requires more configuration in total. Not only does your monitoring system need to know what service instances should exist, but your service instances now also need to know how to reach your monitoring system. A pull approach not only requires less configuration, it also makes your monitoring setup more flexible. With pull, you can just run a copy of production monitoring on your laptop to experiment with it. It also allows you just fetch metrics with some other tool or inspect metrics endpoints manually. To get high availability, pull allows you to just run two identically configured Prometheus servers in parallel. And lastly, if you have to move the endpoint under which your monitoring is reachable, a pull approach does not require you to reconfigure all of your metrics sources.
    * https://prometheus.io/blog/2016/07/23/pull-does-not-scale-or-does-it/

* tracing (comment c'est fait) : https://opentracing.io/docs/best-practices/
* https://epsagon.com/blog/distributed-tracing-the-right-framework-and-getting-started/

* dessin : 
    * https://www.apmdigest.com/distributed-tracing-the-next-step-of-apm
    * https://medium.com/velotio-perspectives/a-comprehensive-tutorial-to-implementing-opentracing-with-jaeger-a01752e1a8ce

* tutoriel datadog (intéret intégration) : https://docs.datadoghq.com/tracing/

* distributed tracing dans les monolithes : https://www.quora.com/Can-distributed-tracing-be-applied-to-monolithic-apps-and-not-only-microservices

* centralisation de logs

* monitoring vs observability : 
    * https://www.perforce.com/blog/vcs/what-observability-and-how-evolve-monitoring
    * https://thenewstack.io/monitoring-and-observability-whats-the-difference-and-why-does-it-matter/
    * https://blog.twitter.com/engineering/en_us/a/2013/observability-at-twitter.html
    * https://www.elastic.co/fr/blog/observability-with-the-elastic-stack
        * L’observabilité n’est pas un composant qu’on livre dans un paquet. C’est un attribut d’un système que vous construisez, au même titre que la facilité d’utilisation, la haute disponibilité et la stabilité
        * les opérateurs soient capables de détecter les comportements indésirables (p. ex. indisponibilité du service, erreurs, réponses lentes) et qu’ils disposent d’informations exploitables pour déterminer la cause du problème avec efficacité (p. ex. logs d’événements détaillés, informations granulaires sur l’utilisation des ressources, traces d’applications).
        * dessins sur l'observabilité
        *  indicateurs et objectifs de niveau de service, il s’agit de mesures de réussite mises en place en interne qui permettent de jauger les systèmes de production. Si une obligation contractuelle impose de respecter ces indicateurs et objectifs de niveau de service, un accord de niveau de service est alors mis en place. Parmi les exemples courants d’indicateurs de niveau de service, citons la disponibilité d’un système, pour laquelle vous pouvez définir un objectif de niveau de service de 99,999 %. La disponibilité d’un système représente aussi l’accord de niveau de service que l’on présente le plus souvent aux clients externes. Néanmoins, en interne, vos indicateurs et objectifs de niveau de service peuvent s’avérer bien plus granulaires, et ces facteurs critiques du comportement des systèmes de production sont soumis au monitoring et à l’alerting, lesquels constituent la base de toute initiative d’observabilité. Cet aspect de l’observabilité est également connu sous le nom de « monitoring ».    
        * mise en place : 
            * on collecte des indicateurs dans un premier système (en général une base de données temporelles ou un service SaaS pour le monitoring des ressources)
            * on collecte les logs dans un deuxième système (sans surprise, la Suite ELK habituellement)
            *  puis on utilise encore un troisième outil pour instrumenter les applications, et ainsi, effectuer le traçage au niveau des requêtes.
            * pb : retrouver l'origine du problème dans plusieurs outils d'analyse différents
            * solution datastore unique 
    * dessins (séparation des outils)
    * vidéos

* Aller plus loin sur l'observabilité : 
    * ingénierie de fiabilité des sites (SRE) (twitter / livre qui n'en parle pas mais pose des concepts : https://landing.google.com/sre/books/)
    * https://engineering.salesforce.com/what-is-observability-d175eb6cd2e4


* outils : 
    * https://docs.datadoghq.com/tracing/
    * new relic 

* 3 pilliers de l'observabilité:
        * métriques
        * logging
        * traces


* tracage 
    * intéressant pour le distribué 
        * suivi de la latence
        * détermination de la cause d'un problème

* mesure de perfs : 
    * jmeter : http://jmeter.apache.org/usermanual/build-web-test-plan.html
    * locust : https://locust.io/


* django prometheus : 
    * https://gdevops.gitlab.io/tuto_sysops/monitoring/prometheus/grafana/dashboards/django/django.html
    * https://grafana.com/grafana/dashboards/9528

Why do I need OpenTracing?

IT and DevOps teams can use distributed tracing to monitor applications. Distributed tracing is particularly well-suited to debugging and monitoring modern distributed software architectures, such as microservices. Developers can use distributed tracing to help debug and optimize their code.

* ES et open tracing : https://www.elastic.co/fr/blog/distributed-tracing-opentracing-and-elastic-apm


* url :
    * jaeger : http://127.0.0.1:16686/trace/ef1cee963abe0130
    * prometheus : http://localhost:9090/alerts
    * graphana : http://localhost:3000/d/rYdddlPWk/node-exporter-full?tab=queries&orgId=1&fullscreen&edit&panelId=152
    * kibana : http://localhost:5601/app/apm#/services/hnclone/transactions/view?rangeFrom=2020-02-01T12:22:00.000Z&rangeTo=2020-02-01T12:28:00.000Z&refreshPaused=true&refreshInterval=0&traceId=fbd6f38651f7ed24c62fcba6be0c5d38&transactionId=1ba3cd959559d59c&transactionName=GET%20news.views.index&transactionType=request&flyoutDetailTab=&waterfallItemId=&_g=()&kuery=


# Grep pour analyser les logs

(mfalce@glados){23:22}~/Documents/pro/projets/oh_ce_cours_formation/domaines/devops/fr/presentation:master ✗ ➭ journalctl | grep "glados sudo" | grep COMMAND |  cut -d ";" -f4 | cut -d " " -f 2 | sort | uniq -c | sort -n 

      1 COMMAND=/usr/bin/bluetoothctl
      1 COMMAND=/usr/bin/chmod
      1 COMMAND=/usr/bin/cp
      1 COMMAND=/usr/bin/gem
      1 COMMAND=/usr/bin/ln
      1 COMMAND=/usr/bin/salt-master
      1 COMMAND=/usr/bin/strace
      1 COMMAND=/usr/bin/su
      1 COMMAND=/usr/bin/tee
      1 COMMAND=/usr/bin/uname
      1 COMMAND=/usr/sbin/reboot
      1 COMMAND=/usr/sbin/service
      1 COMMAND=/usr/sbin/setenforce
      1 COMMAND=/usr/share/lpf/scripts/lpf-pkgbuild
      2 COMMAND=/usr/bin/cat
      2 COMMAND=/usr/bin/cd
      2 COMMAND=/usr/bin/mkdir
      3 COMMAND=/usr/bin/salt-key
      3 COMMAND=/usr/sbin/akmods
      3 COMMAND=/usr/sbin/fsck
      3 COMMAND=/usr/sbin/ip
      3 COMMAND=/usr/sbin/rmmod
      3 COMMAND=/usr/sbin/swapon
      4 COMMAND=/usr/bin/mount
      4 COMMAND=/usr/bin/netstat
      4 COMMAND=/usr/bin/nmcli
      4 COMMAND=/usr/bin/sh
      4 COMMAND=/usr/sbin/ifup
      4 COMMAND=/usr/sbin/modprobe
      4 COMMAND=/usr/sbin/swapoff
      5 COMMAND=/usr/sbin/powertop
      6 COMMAND=/usr/bin/chown
      6 COMMAND=/usr/bin/ls
      8 COMMAND=/usr/bin/rpm
      8 COMMAND=/usr/bin/salt
      9 COMMAND=/usr/sbin/iw
     10 COMMAND=/usr/bin/salt-call
     19 COMMAND=/usr/bin/dnf
     19 COMMAND=/usr/bin/docker
     36 COMMAND=/usr/bin/vim
     40 COMMAND=/usr/bin/journalctl
     63 COMMAND=/usr/bin/docker-compose
     86 COMMAND=/usr/bin/systemctl
     91 COMMAND=/usr/bin/yum
'journalctl' time: 6.196s, cpu: 99%
'grep --color=auto "glados sudo"' time: 6.195s, cpu: 7%
'grep --color=auto COMMAND' time: 6.195s, cpu: 0%
'cut -d ";" -f4' time: 6.193s, cpu: 0%
'cut -d " " -f 2' time: 6.191s, cpu: 0%
'sort' time: 6.184s, cpu: 0%
'uniq -c' time: 6.178s, cpu: 0%
'sort -n' time: 6.177s, cpu: 0%


## 

(mfalce@glados){23:22}~/Documents/pro/projets/oh_ce_cours_formation/domaines/devops/fr/presentation:master ✗ ➭ journalctl | grep "glados sudo" | grep COMMAND | cut -d ";" -f4 | sort | uniq -c | sort -n   

      1  COMMAND=/usr/bin/bluetoothctl
      1  COMMAND=/usr/bin/cat /var/cache/salt/master/roots
      1  COMMAND=/usr/bin/cat /var/cache/salt/master/roots/hash
      1  COMMAND=/usr/bin/cd /var/cache/salt/master/roots
      1  COMMAND=/usr/bin/cd /var/lib/docker/volumes/bitnami-docker-prestashop_prestashop_data/
      1  COMMAND=/usr/bin/chmod 777 -R .
      1  COMMAND=/usr/bin/chown mfalce .
      1  COMMAND=/usr/bin/chown mfalce:mfalce -R .
      1  COMMAND=/usr/bin/chown mfalce -R /var/cache/salt/master/roots/
      1  COMMAND=/usr/bin/chown -R 1000:1000 .
      1  COMMAND=/usr/bin/chown -r 1000:1000 src
      1  COMMAND=/usr/bin/chown -R 1000:1000 src
      1  COMMAND=/usr/bin/cp Gestion Commerciale.desktop /usr/share/applications
      1  COMMAND=/usr/bin/dnf check-update
      1  COMMAND=/usr/bin/dnf config-manager --add-repo https://dl.winehq.org/wine-builds/fedora/30/winehq.repo
      1  COMMAND=/usr/bin/dnf config-manager --add-repo https://download.docker.com/linux/fedora/docker-ce.repo
      1  COMMAND=/usr/bin/dnf copr enable daftaupe/hugo
      1  COMMAND=/usr/bin/dnf install akmod-VirtualBox kernel-devel-5.2.18-200.fc30.x86_64
      1  COMMAND=/usr/bin/dnf install code
      1  COMMAND=/usr/bin/dnf install hugo
      1  COMMAND=/usr/bin/dnf install kernel-devel-5.2.13-200.fc30.x86_64
      1  COMMAND=/usr/bin/dnf install libva-vdpau-driver libva-utils
      1  COMMAND=/usr/bin/dnf install obs-studio
      1  COMMAND=/usr/bin/dnf install winehq-stable
      1  COMMAND=/usr/bin/dnf install xorg-x11-drv-nvidia-libs.i686
      1  COMMAND=/usr/bin/docker build
      1  COMMAND=/usr/bin/docker-compose build prestashop
      1  COMMAND=/usr/bin/docker-compose exec prestashop volume
      1  COMMAND=/usr/bin/docker-compose exec prestashop volume ls
      1  COMMAND=/usr/bin/docker-compose run prestashop volume ls
      1  COMMAND=/usr/bin/docker-compose run reborn-docker-compose-presta_prestashop_1 /bin/bash
      1  COMMAND=/usr/bin/docker-compose up prestashop
      1  COMMAND=/usr/bin/docker-compose volume
      1  COMMAND=/usr/bin/docker-compose volume ls
      1  COMMAND=/usr/bin/docker prestashop
      1  COMMAND=/usr/bin/docker ssh prastashop
      1  COMMAND=/usr/bin/docker volume create --name=mariadb_data
      1  COMMAND=/usr/bin/docker volume inspect bitnami-docker-prestashop_prestashop_data
      1  COMMAND=/usr/bin/docker volume rm
      1  COMMAND=/usr/bin/gem install mailcatcher
      1  COMMAND=/usr/bin/journalctl -f
      1  COMMAND=/usr/bin/journalctl -fu apm-server
      1  COMMAND=/usr/bin/journalctl -h
      1  COMMAND=/usr/bin/journalctl --since 2020-01-24 12:00:00
      1  COMMAND=/usr/bin/journalctl -U 01/24/2020
      1  COMMAND=/usr/bin/journalctl -U 2020-01-24 12:00
      1  COMMAND=/usr/bin/journalctl -U 2020-01-24 12:00:00
      1  COMMAND=/usr/bin/journalctl -U 24/01/2020
      1  COMMAND=/usr/bin/journalctl -U 24 Jan 2020
      1  COMMAND=/usr/bin/journalctl -u apm-server
      1  COMMAND=/usr/bin/journalctl -U Fri 24 Jan 2020
      1  COMMAND=/usr/bin/ln -s lib lib32
      1  COMMAND=/usr/bin/ls --color=auto
      1  COMMAND=/usr/bin/ls --color=auto -llah /usr/bin/python
      1  COMMAND=/usr/bin/ls --color=auto -llah /usr/bin/python2
      1  COMMAND=/usr/bin/ls --color=auto -llah /usr/bin/python2.7
      1  COMMAND=/usr/bin/ls --color=auto -llah /usr/bin/salt
      1  COMMAND=/usr/bin/ls --color=auto /usr/bin/salt
      1  COMMAND=/usr/bin/mkdir hash
      1  COMMAND=/usr/bin/mkdir /media/partage
      1  COMMAND=/usr/bin/mount -o remount,exec /tmp
      1  COMMAND=/usr/bin/mount -t nfs 192.168.0.17:/volume1/public /media/partage
      1  COMMAND=/usr/bin/rpm --import https://artifacts.elastic.co/GPG-KEY-elasticsearch
      1  COMMAND=/usr/bin/rpm -U ./teams-for-linux-0.0.7.x86_64.rpm
      1  COMMAND=/usr/bin/rpm -vi apm-server-7.5.2-x86_64.rpm
      1  COMMAND=/usr/bin/salt-call * grains.items sanitize=True
      1  COMMAND=/usr/bin/salt-call grains.items sanitize=True
      1  COMMAND=/usr/bin/salt-call -l all --state-verbose=True state.apply
      1  COMMAND=/usr/bin/salt-call -l=all --state-verbose=True state.apply
      1  COMMAND=/usr/bin/salt-call --state-verbose=True state.apply
      1  COMMAND=/usr/bin/salt * grains.items sanitize=True
      1  COMMAND=/usr/bin/salt-key
      1  COMMAND=/usr/bin/salt-key -a glados
      1  COMMAND=/usr/bin/salt-key -h
      1  COMMAND=/usr/bin/salt-master -l debug
      1  COMMAND=/usr/bin/sh install_salt.sh -P
      1  COMMAND=/usr/bin/sh install_salt.sh -P -M
      1  COMMAND=/usr/bin/strace systemctl status network-manager
      1  COMMAND=/usr/bin/su
      1  COMMAND=/usr/bin/systemctl enable --now kibana
      1  COMMAND=/usr/bin/systemctl enable powertop
      1  COMMAND=/usr/bin/systemctl reload salt-minion
      1  COMMAND=/usr/bin/systemctl restart bluetooth.service
      1  COMMAND=/usr/bin/systemctl restart kibana
      1  COMMAND=/usr/bin/systemctl restart systemd-modules-load.service
      1  COMMAND=/usr/bin/systemctl start docker
      1  COMMAND=/usr/bin/systemctl start powertop
      1  COMMAND=/usr/bin/systemctl start redis
      1  COMMAND=/usr/bin/systemctl start salt-master
      1  COMMAND=/usr/bin/systemctl start salt-minion
      1  COMMAND=/usr/bin/systemctl status
      1  COMMAND=/usr/bin/systemctl status bluettooth
      1  COMMAND=/usr/bin/systemctl status list
      1  COMMAND=/usr/bin/systemctl status network-manager
      1  COMMAND=/usr/bin/systemctl status obexd
      1  COMMAND=/usr/bin/tee /etc/yum.repos.d/elasticsearch.repo
      1  COMMAND=/usr/bin/uname -a
      1  COMMAND=/usr/bin/vim /etc/apm-server/apm-server.yml
      1  COMMAND=/usr/bin/vim /etc/elasticsearch/jvm.options
      1  COMMAND=/usr/bin/vim /etc/fstab
      1  COMMAND=/usr/bin/vim /etc/selinux/config
      1  COMMAND=/usr/bin/vim /usr/lib/python2.7/site-packages/salt/utils/systemd.py
      1  COMMAND=/usr/bin/vim /usr/share/perl5/Locale/Po4a/LaTeX.pm
      1  COMMAND=/usr/bin/yum clean all
      1  COMMAND=/usr/bin/yum install BirtualBox
      1  COMMAND=/usr/bin/yum install borgbackup.x86_64
      1  COMMAND=/usr/bin/yum install --enablerepo=elasticsearch elasticsearch
      1  COMMAND=/usr/bin/yum install filezilla.x86_64
      1  COMMAND=/usr/bin/yum install filezilla.x86_64 a
      1  COMMAND=/usr/bin/yum install ftp
      1  COMMAND=/usr/bin/yum install gimp
      1  COMMAND=/usr/bin/yum install glxgears
      1  COMMAND=/usr/bin/yum install htop powertop tlp
      1  COMMAND=/usr/bin/yum install inkscape
      1  COMMAND=/usr/bin/yum install java-1.8.0-openjdk
      1  COMMAND=/usr/bin/yum install jmeter
      1  COMMAND=/usr/bin/yum install jmeters.x86_64
      1  COMMAND=/usr/bin/yum install kdeenlive
      1  COMMAND=/usr/bin/yum install kdenlive.x86_64
      1  COMMAND=/usr/bin/yum install libappindicator
      1  COMMAND=/usr/bin/yum install libfaketime.x86_64
      1  COMMAND=/usr/bin/yum install libffi-devel
      1  COMMAND=/usr/bin/yum install mailcatcher
      1  COMMAND=/usr/bin/yum install mesa-dri-drivers.i686
      1  COMMAND=/usr/bin/yum install mod_auth_ntlm_winbind.x86_64
      1  COMMAND=/usr/bin/yum install mplayer
      1  COMMAND=/usr/bin/yum install nco
      1  COMMAND=/usr/bin/yum install nfs-common
      1  COMMAND=/usr/bin/yum install openssl-devel.x86_64
      1  COMMAND=/usr/bin/yum install po4a
      1  COMMAND=/usr/bin/yum install poedit
      1  COMMAND=/usr/bin/yum install python3-devel.x86_64
      1  COMMAND=/usr/bin/yum install redis
      1  COMMAND=/usr/bin/yum install salt-master.noarch salt-minion.noarch
      1  COMMAND=/usr/bin/yum install shotwell
      1  COMMAND=/usr/bin/yum install texmaker
      1  COMMAND=/usr/bin/yum install thunderbird.x86_64
      1  COMMAND=/usr/bin/yum install vagrant
      1  COMMAND=/usr/bin/yum install virtualbox
      1  COMMAND=/usr/bin/yum install VirtualBox
      1  COMMAND=/usr/bin/yum install vlc
      1  COMMAND=/usr/bin/yum install winbind
      1  COMMAND=/usr/bin/yum install xelatex
      1  COMMAND=/usr/bin/yum install -y audacity
      1  COMMAND=/usr/bin/yum install -y golang-bin
      1  COMMAND=/usr/bin/yum install -y obs
      1  COMMAND=/usr/bin/yum install youtube-dl
      1  COMMAND=/usr/bin/yum install -y speedtest-cli
      1  COMMAND=/usr/bin/yum install -y transmission-cli.x86_64
      1  COMMAND=/usr/bin/yum install -y transmission.x86_64
      1  COMMAND=/usr/bin/yum makecache
      1  COMMAND=/usr/bin/yum -qi kibana
      1  COMMAND=/usr/bin/yum remove salt-minion.noarch salt-master.noarch
      1  COMMAND=/usr/bin/yum remove teams-for-linux.x86_64
      1  COMMAND=/usr/bin/yum remove tlp
      1  COMMAND=/usr/bin/yum search winbind
      1  COMMAND=/usr/bin/yum -y install elasticsearch kibana logstash
      1  COMMAND=/usr/bin/yum -y install java-openjdk-devel java-openjdk
      1  COMMAND=/usr/sbin/akmods --force
      1  COMMAND=/usr/sbin/fsck -y /dev/sda
      1  COMMAND=/usr/sbin/fsck -y /dev/sda1
      1  COMMAND=/usr/sbin/fsck -y /dev/sdb1
      1  COMMAND=/usr/sbin/ifup
      1  COMMAND=/usr/sbin/ifup wlp58s0
      1  COMMAND=/usr/sbin/ip
      1  COMMAND=/usr/sbin/ip uo
      1  COMMAND=/usr/sbin/ip up
      1  COMMAND=/usr/sbin/iw
      1  COMMAND=/usr/sbin/iw ~~ link
      1  COMMAND=/usr/sbin/iw ~~link
      1  COMMAND=/usr/sbin/iw list
      1  COMMAND=/usr/sbin/iw phy
      1  COMMAND=/usr/sbin/iw phy list
      1  COMMAND=/usr/sbin/iw scan
      1  COMMAND=/usr/sbin/iw wlan0
      1  COMMAND=/usr/sbin/iw wlan0 info
      1  COMMAND=/usr/sbin/modprobe vboxdrv
      1  COMMAND=/usr/sbin/reboot
      1  COMMAND=/usr/sbin/service apm-server start
      1  COMMAND=/usr/sbin/setenforce 0
      1  COMMAND=/usr/sbin/swapoff -a
      1  COMMAND=/usr/sbin/swapoff -f
      1  COMMAND=/usr/sbin/swapon
      1  COMMAND=/usr/sbin/swapon -a
      1  COMMAND=/usr/sbin/swapon -f
      1  COMMAND=/usr/share/lpf/scripts/lpf-pkgbuild scan spotify-client
      2  COMMAND=/usr/bin/dnf install docker-ce docker-ce-cli containerd.io
      2  COMMAND=/usr/bin/dnf install kernel-dev-5.2.13-200.fc30.x86_64
      2  COMMAND=/usr/bin/docker-compose build
      2  COMMAND=/usr/bin/docker-compose exec prestashop id
      2  COMMAND=/usr/bin/docker-compose run prestashop /bin/shell
      2  COMMAND=/usr/bin/docker-compose up -d
      2  COMMAND=/usr/bin/docker ps
      2  COMMAND=/usr/bin/docker volume ls
      2  COMMAND=/usr/bin/docker volume rm bitnami-docker-prestashop_prestashop_data bitnami-docker-prestashop_mariadb_data
      2  COMMAND=/usr/bin/journalctl -U 2020-01-24
      2  COMMAND=/usr/bin/mount -t nfs 192.168.0.17/volume1/public /media/partage
      2  COMMAND=/usr/bin/nmcli radio wifi off
      2  COMMAND=/usr/bin/nmcli radio wifi on
      2  COMMAND=/usr/bin/rpm --import https://packages.microsoft.com/keys/microsoft.asc
      2  COMMAND=/usr/bin/salt-call test.version
      2  COMMAND=/usr/bin/sh -c echo -e "[code]\nname=Visual Studio Code\nbaseurl=https://packages.microsoft.com/yumrepos/vscode\nenabled=1\ngpgcheck=1\ngpgkey=https://packages.microsoft.com/keys/microsoft.asc" > /etc/yum.repos.d/vscode.repo
      2  COMMAND=/usr/bin/systemctl enable --now elasticsearch.service
      2  COMMAND=/usr/bin/systemctl status bluetooth.service
      2  COMMAND=/usr/bin/systemctl status -l
      2  COMMAND=/usr/bin/systemctl status network
      2  COMMAND=/usr/bin/yum install mesa*.i686
      2  COMMAND=/usr/bin/yum install pandoc
      2  COMMAND=/usr/bin/yum install vim
      2  COMMAND=/usr/bin/yum -y install gcc gcc-c++
      2  COMMAND=/usr/bin/yum -y install python36-devel
      2  COMMAND=/usr/bin/yum -y install sqlite-devel ruby-devel
      2  COMMAND=/usr/sbin/akmods
      2  COMMAND=/usr/sbin/ifup wlan0
      2  COMMAND=/usr/sbin/powertop --calibrate
      2  COMMAND=/usr/sbin/swapoff
      3  COMMAND=/usr/bin/dnf install akmod-VirtualBox kernel-devel-5.2.13-200.fc30.x86_64
      3  COMMAND=/usr/bin/docker-compose rm
      3  COMMAND=/usr/bin/docker volume rm bitnami-docker-prestashop_prestashop_data
      3  COMMAND=/usr/bin/journalctl -f -u salt-master.service
      3  COMMAND=/usr/bin/rpm -Uhv ./teams-for-linux-0.0.7.x86_64.rpm
      3  COMMAND=/usr/bin/salt-call state.apply
      3  COMMAND=/usr/bin/systemctl restart crashplan
      3  COMMAND=/usr/bin/yum -y install elasticsearch
      3  COMMAND=/usr/sbin/modprobe btusb
      3  COMMAND=/usr/sbin/powertop
      3  COMMAND=/usr/sbin/rmmod btusb
      4  COMMAND=/usr/bin/docker-compose down --volumes
      4  COMMAND=/usr/bin/docker volume rm bitnami-docker-prestashop_mariadb_data
      4  COMMAND=/usr/bin/journalctl -f -u salt-minion.service
      4  COMMAND=/usr/bin/netstat -tulpn
      4  COMMAND=/usr/bin/systemctl status crashplan
      4  COMMAND=/usr/bin/systemctl status redis
      4  COMMAND=/usr/bin/vim /etc/salt/minion
      4  COMMAND=/usr/bin/yum install dia
      5  COMMAND=/usr/bin/docker-compose run prestashop /bin/bash
      5  COMMAND=/usr/bin/yum update
      7  COMMAND=/usr/bin/journalctl
      7  COMMAND=/usr/bin/salt * state.apply
      7  COMMAND=/usr/bin/vim /etc/salt/master
      9  COMMAND=/usr/bin/systemctl start salt-master.service
      9  COMMAND=/usr/bin/vim /usr/share/perl5/vendor_perl/Locale/Po4a/LaTeX.pm
     10  COMMAND=/usr/bin/systemctl start kibana
     10  COMMAND=/usr/bin/systemctl stop salt-master.service
     10  COMMAND=/usr/bin/vim /etc/kibana/kibana.yml
     11  COMMAND=/usr/bin/systemctl start salt-minion.service
     11  COMMAND=/usr/bin/systemctl stop salt-minion.service
     12  COMMAND=/usr/bin/yum install texlive-scheme-full
     13  COMMAND=/usr/bin/journalctl -u kibana
     35  COMMAND=/usr/bin/docker-compose up
'journalctl' time: 6.271s, cpu: 99%
'grep --color=auto "glados sudo"' time: 6.271s, cpu: 6%
'grep --color=auto COMMAND' time: 6.270s, cpu: 0%
'cut -d ";" -f4' time: 6.268s, cpu: 0%
'sort' time: 6.265s, cpu: 0%
'uniq -c' time: 6.263s, cpu: 0%
'sort -n' time: 6.262s, cpu: 0%
